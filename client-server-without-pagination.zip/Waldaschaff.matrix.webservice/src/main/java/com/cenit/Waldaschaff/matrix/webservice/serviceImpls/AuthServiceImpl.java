package com.cenit.Waldaschaff.matrix.webservice.serviceImpls;

import com.cenit.Waldaschaff.matrix.webservice.entities.Auth;
import com.cenit.Waldaschaff.matrix.webservice.entities.User;
import com.cenit.Waldaschaff.matrix.webservice.repositories.AuthRepository;
import com.cenit.Waldaschaff.matrix.webservice.repositories.UserRepository;
import com.cenit.Waldaschaff.matrix.webservice.services.AuthService;
import com.cenit.Waldaschaff.matrix.webservice.services.UserService;
import org.springframework.stereotype.Service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

@Service
public class AuthServiceImpl implements AuthService {

	AuthRepository authRepository;

	public AuthServiceImpl(AuthRepository authRepository) {
		super();
		this.authRepository = authRepository;
	}

	@Override
	public Auth findOneByUsername(String username) {
		return this.authRepository.findOneByUsername(username);
	}

	@Override
	public Auth findOneByUsernameAndPassword(String username, String password) {
		return this.authRepository.findOneByUsernameAndPassword(username, password);
	}

	@Override
	public Auth findOneByToken(String token) {
		return this.authRepository.findOneByToken(token);
	}

	@Override
	public Auth login(Auth user) {
		String token = generateSHA256Hash(String.valueOf(System.currentTimeMillis()));
		user.setToken(token);
		authRepository.save(user);
		return user;
	}

	@Override
	public String logout(String token) {
		Auth user = this.authRepository.findOneByToken(token);
		if (user != null) {
			user.setToken("null");
			authRepository.save(user);
			return "DONE";
		}
		return "FAILED";
	}


	private String generateSHA256Hash(String input) {
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] encodedhash = digest.digest(input.getBytes());
			StringBuilder hexString = new StringBuilder();
			for (byte b : encodedhash) {
				String hex = Integer.toHexString(0xff & b);
				if (hex.length() == 1) {
					hexString.append('0');
				}
				hexString.append(hex);
			}
			return hexString.toString();
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
	}

}
