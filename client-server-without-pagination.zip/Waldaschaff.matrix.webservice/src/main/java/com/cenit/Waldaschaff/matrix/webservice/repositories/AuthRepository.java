package com.cenit.Waldaschaff.matrix.webservice.repositories;

import com.cenit.Waldaschaff.matrix.webservice.entities.Auth;
import com.cenit.Waldaschaff.matrix.webservice.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuthRepository extends JpaRepository<Auth, Long> {
	
	public Auth findOneByUsername(String username);

	public Auth findOneByUsernameAndPassword(String username, String password);

	public Auth findOneByToken(String token);
}
