package com.cenit.Waldaschaff.matrix.webservice;

import com.cenit.Waldaschaff.matrix.webservice.components.ApiCorsFilter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.CrossOrigin;

@SpringBootApplication
@CrossOrigin(value = "*")
public class Application {

	@Bean
	@Order(1)
	public FilterRegistrationBean<ApiCorsFilter> ApiFilter() {
		FilterRegistrationBean<ApiCorsFilter> registration = new FilterRegistrationBean<>();
		registration.setFilter(theActualFilter());
		// In case you want the filter to apply to specific URL patterns only
		registration.addUrlPatterns("/api/*");
		return registration;
	}

	@Bean
	public ApiCorsFilter theActualFilter() {
		return new ApiCorsFilter(); // now this is a Spring bean
	}

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
}
