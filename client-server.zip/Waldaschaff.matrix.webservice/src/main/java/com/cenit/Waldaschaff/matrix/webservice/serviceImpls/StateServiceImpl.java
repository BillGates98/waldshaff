package com.cenit.Waldaschaff.matrix.webservice.serviceImpls;

import com.cenit.Waldaschaff.matrix.webservice.entities.State;
import com.cenit.Waldaschaff.matrix.webservice.entities.User;
import com.cenit.Waldaschaff.matrix.webservice.repositories.StateRepository;
import com.cenit.Waldaschaff.matrix.webservice.repositories.UserRepository;
import com.cenit.Waldaschaff.matrix.webservice.services.StateService;
import com.cenit.Waldaschaff.matrix.webservice.services.UserService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class StateServiceImpl implements StateService {

	StateRepository stateRepository;

	public StateServiceImpl(StateRepository stateRepository) {
		super();
		this.stateRepository = stateRepository;
	}

	@Override
	public State findOneById(Long id) {
		// TODO Auto-generated method stub
		return this.stateRepository.findOneById(id);
	}

	@Override
	public ArrayList<State> findByEntityId(String entityId) {
		return this.stateRepository.findByEntityId(entityId);
	}

}
