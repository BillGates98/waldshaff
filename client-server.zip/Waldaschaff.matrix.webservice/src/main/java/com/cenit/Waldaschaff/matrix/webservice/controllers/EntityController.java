package com.cenit.Waldaschaff.matrix.webservice.controllers;

import java.io.*;
import java.nio.channels.FileChannel;
import java.util.*;
import com.cenit.Waldaschaff.matrix.webservice.services.FileZippingService;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cenit.Waldaschaff.matrix.webservice.entities.Entity;
import com.cenit.Waldaschaff.matrix.webservice.services.EntityService;
import com.cenit.Waldaschaff.matrix.webservice.services.RelationshipService;

import javax.servlet.http.HttpServletResponse;

@RestController
@RequestMapping(value="/api/entities")
@CrossOrigin(origins = "*")
public class EntityController {

	
	EntityService entityService;
	RelationshipService relationshipService;
	@Value("${downloading.dataPath}")
	String parentPath;

	public EntityController(EntityService entityService, RelationshipService relationshipService) {
		this.entityService = entityService;
		this.relationshipService = relationshipService;
	}

	@RequestMapping(value = "/types", method = RequestMethod.GET)
	HttpEntity<Object> entityTypeResource() {
		ArrayList<String> data = this.entityService.findTypes();
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@RequestMapping(value = "/{id}/relation-definitions", method = RequestMethod.GET)
	HttpEntity<HashMap<String, String>> entityRelationDefinitions(@PathVariable("id") String id) {
		HashMap<String, String> output = this.entityService.findRelationDefinitions(id);
		return new ResponseEntity<>(output, HttpStatus.OK);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	HttpEntity<Entity> entityResource(@PathVariable("id") String id) {
	   Entity entity = this.entityService.findOneById(id);
	   return new ResponseEntity<>(entity, HttpStatus.OK);
	}

	@RequestMapping(value = "/{id}/parents", method = RequestMethod.GET)
	HttpEntity<Object> parentEntitiesResource(@PathVariable("id") String id) {
		ArrayList<Entity> entities = (ArrayList<Entity>) this.entityService.findParentEntityByEntityId(id);
		return new ResponseEntity<>(entities, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/{id}/relationships", method = RequestMethod.GET)
	HttpEntity<Object> entityWithRelationshipResource(@PathVariable("id") String id) {
		ArrayList<Entity> data = new ArrayList<>();
		Entity entity = this.entityService.findOneById(id);
		if (entity != null) {
			data.add(entity);
			ArrayList<Entity> results = this.entityService.findEntityTree(entity.getId(), "from", "simple");
			if (results != null && !results.isEmpty()) {
				data.addAll(results);
			}
			return new ResponseEntity<>(data, HttpStatus.OK);
		}
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@RequestMapping(value = "/filtered-by", method = RequestMethod.GET)
	HttpEntity<Object> giveAssociatedNames(@RequestParam("type") String type,
									@RequestParam("value") String value) {
		List<Entity> data = this.entityService.findEntityByFilteringNames(type, value);
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@RequestMapping(value = "/single-tree", method = RequestMethod.GET)
	HttpEntity<Object> entityByName(@RequestParam("id") String entityId) {
		ArrayList<Entity> data = (ArrayList<Entity>) this.entityService.findTreeEntityById(entityId);
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@RequestMapping(value = "/search-by", method = RequestMethod.GET)
	HttpEntity<Object> entityByName(@RequestParam("type") String type,
									@RequestParam("value") String value, @RequestParam("wbom") boolean wbom, @RequestParam("page") int page) {
		// System.out.println(" field : " + type + " value : " + value);
		List<Entity> data = null;
		if (wbom) data = this.entityService.findEntityByStartingWith(type, value, wbom, -1);
		else data = this.entityService.findEntityByStartingWith(type, value, wbom, page);
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	/*
		Downloading section
	 */
	@RequestMapping(value = "/export", method=RequestMethod.GET, produces="application/zip")
	public void getZippedFiles(HttpServletResponse response, @RequestParam("ids") String entities) throws IOException {

		Object[] entityIds = Arrays.stream(entities.split(";")).toArray();
		ArrayList<Entity> entitiesTree = new ArrayList<>();
		ArrayList<String> selectedFiles = new ArrayList<>();
		String tmpPath = "";
		for(Object value : entityIds) {
			// System.out.println(value);
			entitiesTree = this.entityService.findEntityTree((String) value, "", "export");
			// System.out.println("Total of " + entitiesTree.size() + " elements !");
			for(Entity entity: entitiesTree) {
				if (tmpPath.isEmpty()) tmpPath = "/tmp/" + entity.getType()  +  "_" + entity.getName() + "_" + entity.getRevision();
				if (entity.getPath() != null && !entity.getPath().isEmpty()) {
					ArrayList<String> currentFiles = listFilesForFolder(parentPath + entity.getPath());
					if (currentFiles != null && !currentFiles.isEmpty() && !selectedFiles.containsAll(currentFiles)) {
						// System.out.println(" E >> " + parentPath + entity.getPath());
						selectedFiles.addAll(currentFiles);
					}
				}
			}
		}

		// add the tree text file
		selectedFiles.add(tmpPath + "/treeText.txt");
		selectedFiles.add(tmpPath + "/treeXml.xml");
		String filename = tmpPath.replace("/tmp/", "");
		String hintFile = filename + ".zip";
		response.setStatus(HttpServletResponse.SC_OK);
		response.addHeader("Content-Disposition", "attachment; filename=\"" + hintFile + "\"");
		// FileZippingService.zipExportFile(response.getOutputStream(), selectedFiles);
		// clean and copy files to CAD and NON-CAD then
		preparation(selectedFiles, tmpPath);
		// delete tmp path
		FileZippingService.zipExportDirectory(tmpPath, response.getOutputStream());
	}

	public ArrayList<String> listFilesForFolder(final String folder) {
		File _folder = new File(folder);
		ArrayList<String> selectedFiles = new ArrayList<>();
		if (_folder.exists() && _folder.listFiles() != null) {
			for (final File fileEntry : Objects.requireNonNull(_folder.listFiles())) {
				selectedFiles.add(fileEntry.getPath());
			}
		}
		return selectedFiles;
	}

	public void preparation(ArrayList<String> files, String tmpPath) {
		String cad = tmpPath + "/CAD/";
		String nonCad = tmpPath + "/non-CAD/";
		// String pdfs = tmpPath + "/PDFs/";
		int subDirCount = 2;

		File fCad = new File(cad);
		File fNonCad = new File(nonCad);
		// File fPdfs = new File(pdfs);
        try {
			FileUtils.deleteDirectory(fCad);
            if(!fCad.exists()) {
				FileUtils.forceMkdir(fCad);
				for(int i = 1; i <= subDirCount; i++) {
					FileUtils.forceMkdir(new File(fCad.getAbsolutePath() + "/" + i));
				}
			}
			FileUtils.deleteDirectory(fNonCad);
			if(!fNonCad.exists()) {
				FileUtils.forceMkdir(fNonCad);
				for(int i = 1; i <= subDirCount; i++) {
					FileUtils.forceMkdir(new File(fNonCad.getAbsolutePath() + "/" + i));
				}
			}
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

		for(String file: files) {
			File _file = new File(file);
            try {
				System.out.println(file);
				copyFile(_file.getPath(), fCad.getPath() + "/1/");
				copyFile(_file.getPath(), fNonCad.getPath() + "/1/");
				// copyFile(_file.getPath(), fPdfs.getPath());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

	public void copyFile(String sourceFilePath, String destinationDirectoryPath) throws IOException {
		File sourceFile = new File(sourceFilePath);
		File destinationDirectory = new File(destinationDirectoryPath);

		// Check if the source file exists
		if (!sourceFile.exists()) {
			throw new FileNotFoundException("Source file not found: " + sourceFilePath);
		}

		// Check if the destination directory exists and create it if it doesn't
		if (!destinationDirectory.exists()) {
			if (!destinationDirectory.mkdirs()) {
				throw new IOException("Failed to create destination directory: " + destinationDirectoryPath);
			}
		}

		// Get the filename from the source file path
		String fileName = sourceFile.getName();

		// Create the destination file path by combining the destination directory path and filename
		String destinationFilePath = destinationDirectoryPath + File.separator + fileName;

		// Copy the file using FileChannel
		try (FileChannel sourceChannel = new FileInputStream(sourceFile).getChannel();
			 FileChannel destinationChannel = new FileOutputStream(destinationFilePath).getChannel()) {
			sourceChannel.transferTo(0, sourceFile.length(), destinationChannel);
		}

		// System.out.println("File copied successfully: " + sourceFilePath + " to " + destinationFilePath);
	}


}
