package com.cenit.Waldaschaff.matrix.webservice.serviceImpls;

import org.springframework.stereotype.Service;

import com.cenit.Waldaschaff.matrix.webservice.entities.Attribute;
import com.cenit.Waldaschaff.matrix.webservice.repositories.AttributeRepository;
import com.cenit.Waldaschaff.matrix.webservice.services.AttributeService;

@Service
public class AttributeServiceImpl implements AttributeService {
	
	AttributeRepository attributeRepository;

	public AttributeServiceImpl(AttributeRepository attributeRepository) {
		super();
		this.attributeRepository = attributeRepository;
	}

	@Override
	public Attribute findOneById(Long id) {
		// TODO Auto-generated method stub
		return this.attributeRepository.findOneById(id);
	}

}
