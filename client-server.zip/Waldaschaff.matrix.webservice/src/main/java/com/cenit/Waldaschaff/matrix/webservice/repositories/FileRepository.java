package com.cenit.Waldaschaff.matrix.webservice.repositories;

import com.cenit.Waldaschaff.matrix.webservice.entities.Entity;
import com.cenit.Waldaschaff.matrix.webservice.entities.File;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface FileRepository extends JpaRepository<File, Long> {
	
	public File findOneById(String id);

	public ArrayList<File> findByBusId(String busId);

}
