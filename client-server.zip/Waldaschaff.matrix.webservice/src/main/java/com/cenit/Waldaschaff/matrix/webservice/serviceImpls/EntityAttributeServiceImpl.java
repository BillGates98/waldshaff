package com.cenit.Waldaschaff.matrix.webservice.serviceImpls;

import com.cenit.Waldaschaff.matrix.webservice.entities.Attribute;
import com.cenit.Waldaschaff.matrix.webservice.services.AttributeService;
import org.hibernate.metamodel.model.domain.internal.EntityTypeImpl;
import org.springframework.stereotype.Service;

import com.cenit.Waldaschaff.matrix.webservice.entities.EntityAttribute;
import com.cenit.Waldaschaff.matrix.webservice.repositories.EntityAttributeRepository;
import com.cenit.Waldaschaff.matrix.webservice.services.EntityAttributeService;

import java.util.ArrayList;

@Service
public class EntityAttributeServiceImpl implements EntityAttributeService {
	
	EntityAttributeRepository entityAttributeRepository;
	AttributeService attributeService;

	public EntityAttributeServiceImpl(EntityAttributeRepository entityAttributeRepository, AttributeService attributeService) {
		super();
		this.entityAttributeRepository = entityAttributeRepository;
		this.attributeService = attributeService;
	}


	@Override
	public EntityAttribute findOneById(Long id) {
		// TODO Auto-generated method stub
		return this.entityAttributeRepository.findOneById(id);
	}

	@Override
	public ArrayList<EntityAttribute> findByEntityId(String entityId) {
		ArrayList<EntityAttribute> results = this.entityAttributeRepository.findByEntityId(entityId);
		ArrayList<EntityAttribute> data = new ArrayList<>();
		if ( results != null) {
			for(EntityAttribute item: results) {
				Attribute attribute = this.attributeService.findOneById(Long.valueOf(item.getAttributeId()));
				if (attribute != null) item.setAttributeId(attribute.getName());

				data.add(item);
			}
			return data;
		}
		return null;
	}


}
