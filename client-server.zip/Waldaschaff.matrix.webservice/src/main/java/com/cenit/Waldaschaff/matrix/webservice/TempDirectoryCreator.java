package com.cenit.Waldaschaff.matrix.webservice;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class TempDirectoryCreator {

    public String baseName = "";

    public TempDirectoryCreator(String baseName) {
        this.baseName = baseName;
    }

    public Path getTmpDirectory() {
        try {
            Path tempDirBase = Paths.get(System.getProperty("java.io.tmpdir"));
            Path tempDir = tempDirBase.resolve(baseName);
            // Path tempDir = Files.createTempDirectory(baseName);
            Files.createDirectories(tempDir.resolve("CAD/1"));
            Files.createDirectories(tempDir.resolve("CAD/2"));
            Files.createDirectories(tempDir.resolve("non-CAD/1"));
            Files.createDirectories(tempDir.resolve("non-CAD/2"));
            Files.createDirectories(tempDir.resolve("PDFs"));
            System.out.println("The tree of directories has been created at : " + tempDir.toAbsolutePath().toString());
            return tempDir;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args) {
        (new TempDirectoryCreator("CATProduct_34610.0.701_009")).getTmpDirectory();
    }
}

