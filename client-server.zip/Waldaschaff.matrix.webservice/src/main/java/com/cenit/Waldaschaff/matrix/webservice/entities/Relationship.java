package com.cenit.Waldaschaff.matrix.webservice.entities;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Data;

@Data
@javax.persistence.Entity
@Table(name="relationship")
public class Relationship {
	
	@Id
	@Column(name="id")
	private String id;
	
	@Column(name="parent_entity_id")
	private String parentEntityId;
	
	@Column(name="type")
	private String type;
	
	@Column(name="name")
	private String name;
	
	@Column(name="revision")
	private String revision;
	
	@Column(name="rel_def_ref")
	private String relDefRef;
	
	@Column(name="kind")
	private String kind;
	
	@Column(name="vault_ref")
	private String vaultRef;

	@Column(name="child_entity_id")
	private String childEntityId;

	@Transient
	private int level;


	public Relationship(String Id_,String parentEntityId_,String type_,String name_,String revision_,String relDefRef_,String kind_,String vaultRef_, String childEntityId_)
	{
		this.id = Id_;
		this.parentEntityId = parentEntityId_;
		this.type = type_;
		this.name = name_;
		this.revision = revision_;
		this.relDefRef = relDefRef_;
		this.kind = kind_;
		this.vaultRef = vaultRef_;
		this.childEntityId = childEntityId_;
	}
	
	public Relationship() {
		super();
	}

}
