package com.cenit.Waldaschaff.matrix.webservice.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cenit.Waldaschaff.matrix.webservice.entities.EntityAttribute;

import java.util.ArrayList;

@Repository
public interface EntityAttributeRepository extends JpaRepository<EntityAttribute, Long> {
	
	public EntityAttribute findOneById(Long id);

	public ArrayList<EntityAttribute> findByEntityId(String entityId);
}
