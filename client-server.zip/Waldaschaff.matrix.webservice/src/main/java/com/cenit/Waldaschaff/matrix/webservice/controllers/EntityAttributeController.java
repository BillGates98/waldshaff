package com.cenit.Waldaschaff.matrix.webservice.controllers;

import com.cenit.Waldaschaff.matrix.webservice.entities.Entity;
import com.cenit.Waldaschaff.matrix.webservice.entities.EntityAttribute;
import com.cenit.Waldaschaff.matrix.webservice.services.EntityAttributeService;
import com.cenit.Waldaschaff.matrix.webservice.services.EntityService;
import com.cenit.Waldaschaff.matrix.webservice.services.FileZippingService;
import com.cenit.Waldaschaff.matrix.webservice.services.RelationshipService;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping(value="/api/entity-attribute")
@CrossOrigin(origins = "*")
public class EntityAttributeController {


	EntityAttributeService entityAttributeService;

	public EntityAttributeController(EntityAttributeService entityAttributeService) {
		this.entityAttributeService = entityAttributeService;
	}
	
	@RequestMapping(value = "/{id}/entity", method = RequestMethod.GET)
	HttpEntity<Object> entityAttributesResource(@PathVariable("id") String id) {
		ArrayList<EntityAttribute> data = this.entityAttributeService.findByEntityId(id);
		if (data != null && !data.isEmpty()) {
			return new ResponseEntity<>(data, HttpStatus.OK);
		}
		return new ResponseEntity<>(null, HttpStatus.OK);
	}
}
