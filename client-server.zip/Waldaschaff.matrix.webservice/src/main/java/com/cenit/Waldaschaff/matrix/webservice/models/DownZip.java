package com.cenit.Waldaschaff.matrix.webservice.models;

import lombok.Data;

@Data
public class DownZip {
    private String entities;
}
