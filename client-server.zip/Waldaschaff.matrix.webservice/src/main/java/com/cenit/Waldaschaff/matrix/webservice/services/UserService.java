package com.cenit.Waldaschaff.matrix.webservice.services;

import com.cenit.Waldaschaff.matrix.webservice.entities.User;


public interface UserService {
	
	public User findOneById(Long id);
}
