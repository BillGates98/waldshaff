const host = window.location.hostname ? window.location.hostname : "localhost";
const SERVER = `http://${host}:8009/api/`;

// alert(SERVER);

let currentType = "Projekt";
// let currentType = "Projektstufe";
// let currentType = "CATProduct";
let tracker = {};
let entities = [];
let oldTextLength = 0;

let datasets = [];
let clone_datasets = [];
let parentEntities = [];

let withoutTS = true;

let entityFiles = [];

let currentPageNumber = 0;

let PFB = true;

let currentPage = {
  value: "",
  type: currentType,
  wbom: withoutTS ? "true" : "false",
  page: currentPageNumber,
};


function makeRequest(url, success) {
  if (!url in tracker) {
    tracker[url] = 0;
  }

  if (tracker[url] == 1 && !url.includes("search-by")) {
    return;
  }

  $.ajax({
    url: url,
    type: "GET",
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Authorization": localStorage.getItem('TOKEN')
    },
    success: function (data) {
      success(data);
    },
    error: function (error) {
      console.error("Request error : " + error.statusText);
    },
  });
}

function makeGetRequest(url, success, failure) {
  $.ajax({
    url: url,
    type: "GET",
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Authorization": localStorage.getItem("TOKEN")
    },
    success: function (data) {
      success(data);
    },
    error: function (error) {
      console.error("Request error : " + error.statusText);
      failure(error);
    },
  });
}

function makePostRequest(url, data, success, failure) {
  $.ajax({
      url: url,
      type: "POST",
      data: JSON.stringify(data),
      dataType: "json",
      contentType: "application/json",
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Authorization": localStorage.getItem("TOKEN")
      },
      success: function (_data) {
        success(_data);
      },
      error: function (error) {
          console.error("Request error : " + error.statusText);
          failure(error);
      },
    });
}


function searchEntityByName(value) {
  withoutTS = true;
  $('#current-page').html(currentPage.page+1);
  currentPage.value = value;
  var url =
    SERVER +
    "entities/search-by?type=" +
    currentType +
    "&value={value}".replace("{value}", value) +
    "&wbom={value}".replace("{value}", withoutTS ? "true" : "false") +
    "&page=" + currentPage.page + "&pfb="+PFB;

    $('#loading-gif').show(10);
    $("#loading-text").html("");
  makeRequest(url, function (data) {
    $("#" + contentId).empty();
    datasets = [];
    if (data.length > 0) {
      $.each(data, function (index, item) {
        item.tt_key = item.id;
        item.tt_parent = item.parentEntityId ? item.parentEntityId : 0;
        if (!item.revision || item.revision == "None") item.revision = "-";
        if (!item.creationInfo) item.creationInfo = ""
        else {
          item.creationInfo = new Date(item.creationInfo).toUTCString();
        }
        if (!item.modificationInfo) item.modificationInfo = ""
        else {
          item.modificationInfo = new Date(item.modificationInfo).toUTCString();
        }
        if (!item.stateName) item.stateName = "";
        if (!item.relDefRef) item.relDefRef = "";
        if (!item.kind) item.kind = "";
        if (!item.policyRef) item.policyRef = "";

        if (item.level == 0) {
          item.show_p = true;
          item.show_h = true;
          item.show_c = false;
        } else {
          item.show_p = false;
          item.show_h = false;
          item.show_c = false;
        }

        datasets.push(item);
        clone_datasets.push(item);
        entities.push(item.id);
      });
    } else {
      // currentPageNumber--;
      // currentPage.page = currentPageNumber;
      $("#loading-text").html("No data found");
    }
    console.log("Data obtained : ", datasets);
    $('#current-page').html(currentPage.page+1);
    $('#loading-gif').hide(10);
    fillDataTable(datasets);
  });
}

function searchEntityByEntityId(id) {
  $('#current-page').html(currentPage.page+1);
  // currentPage.value = value;
  withoutTS = false;
  var url = SERVER + "entities/single-tree?id={value}".replace("{value}", id) + "&pfb="+PFB;
    $('#loading-gif').show(10);
    $("#loading-text").html("");
  makeRequest(url, function (data) {
    $("#" + contentId).empty();
    datasets = [];
    clone_datasets = [];
    entities = [];
    if (data.length > 0) {
      $.each(data, function (index, item) {
        item.tt_key = item.id;
        item.tt_parent = item.parentEntityId ? item.parentEntityId : 0;
        if (!item.revision || item.revision == "None") item.revision = "-";
        if (!item.creationInfo) item.creationInfo = ""
        else {
          item.creationInfo = new Date(item.creationInfo).toUTCString();
        }
        if (!item.modificationInfo) item.modificationInfo = ""
        else {
          item.modificationInfo = new Date(item.modificationInfo).toUTCString();
        }
        if (!item.stateName) item.stateName = "";
        if (!item.relDefRef) item.relDefRef = "";
        if (!item.kind) item.kind = "";
        if (!item.policyRef) item.policyRef = "";

        if (item.level == 0) {
          item.show_p = true;
          item.show_h = true;
          item.show_c = false;
        } else {
          item.show_p = false;
          item.show_h = false;
          item.show_c = false;
        }

        datasets.push(item);
        clone_datasets.push(item);
        entities.push(item.id);
      });
    } else {
      // currentPageNumber--;
      // currentPage.page = currentPageNumber;
      $("#loading-text").html("No data found");
    }
    console.log("Data obtained : ", datasets);
    $('#current-page').html(currentPage.page+1);
    $('#loading-gif').hide(10);
    fillDataTable(datasets);
  });
}

/**
 * Actions space */
function removeFromSet(element, list) {
  output = [];
  for (const elt of list) {
    if (!(element == elt)) {
      output.push(elt);
    }
  }
  return output;
}

function removeDuplicates(arr) {
  let unique = arr.reduce(function (acc, curr) {
    if (!acc.includes(curr)) acc.push(curr);
    return acc;
  }, []);
  return unique;
}

$(document).on("click", 'a[id^="type-"]', function () {
  var dropDownId = $(this).attr("id");
  var id = dropDownId.replace("type-", "");
  currentType = id;
  $("#current-type").text(id);
});

function findBySearch(value) {
  if (value.length > 0) {
    // localStorage.setItem("SEARCH", value);
    if (value.includes("*")) value = value.replace("*", "");
    searchEntityByName(value);
  }
}

function fillDataTable(dataset) {
  out = showDataTable(dataset, null);
  datasets = out;
}

function checkLogin() {
  const token = localStorage.getItem("TOKEN");
  const CHECK_URL = SERVER + 'auth/check-auth?token=';
  var tmp = window.location.href;

  if (token !== 'none') {
    makeGetRequest(CHECK_URL + token, function (data) {
      if (data === "BAD") {
        if (tmp.includes("main") ) tmp = tmp.replace("main", "index");
        else if (tmp.includes("/?") ) tmp = tmp.replace("/?", "/index.html?").replace("#", "");
        window.location.href = tmp;
      }
    }, function (error) {
        console.log(error);
    });
  } else {
    if (tmp.includes("main") ) tmp = tmp.replace("main", "index");
    else if (tmp.includes("/?") ) tmp = tmp.replace("/?", "/index.html?").replace("#", "");
    window.location.href = tmp;
  }
}

function logout() {
  const token = localStorage.getItem("TOKEN");
  const LOGOUT_URL = SERVER + 'auth/logout?token=';
  var tmp = window.location.href;
  if (token !== 'none') {
    makePostRequest(LOGOUT_URL + token, {}, function (data) {
      console.log(data);
      if (data.ack === "DONE") {
        localStorage.setItem("TOKEN", "none");
        localStorage.setItem("REMEMBER_ME", "none");
        if (tmp.includes("main") ) tmp = tmp.replace("main.html", "").replace("token="+token, "").replace("#","");
        window.location.href = tmp;
      }

    }, function (error) {
        console.log(error);
    });
  }
}

function getParentEntities(childId='27212.3559.17465.52399') {
  $('#loading-gif').show(10);
  const url = SERVER + `entities/${childId}/parents`;
  var output = [];
  $("#" + parentContentId).empty();
  makeGetRequest(url, function (data) {
    if (data.length > 0) {
      $.each(data, function (index, item) {
        if (!item.revision || item.revision == "None") item.revision = "-";
        if (!item.relDefRef) item.relDefRef = "";
        if (!item.policyRef) item.policyRef = "";
        if (!item.kind) item.kind = "";
        if(index == 0) item.level = 0;
        else item.level = 1;
        $("#" + parentContentId).append(return_parent_table_row(item));
        output.push(item);
      });
      
    }
    console.log("Data obtained : ", output);
    $('#div1-parent').fadeIn(); // Fades in the div
    $('#loading-gif').hide(10);
    parentEntities = output;
  }, function (error) {
      console.log(error);
  });
  return;
}

function getEntityFiles(childId='27212.3559.31743.2327') {
  const url = SERVER + `files/${childId}/entity`;
  var output = [];
  $("#" + fileContentId).empty();
  makeGetRequest(url, function (data) {
    if (data.length > 0) {
      $.each(data, function (index, item) {
        $("#" + fileContentId).append(return_file_table_row(item));
        output.push(item);
      });
      
    }
    console.log("Data obtained Files : ", output);
    $('#div2-parent').fadeIn(); // Fades in the div
    entityFiles = output;
  }, function (error) {
      console.log(error);
  });
  return;
}

function checkRelationShipAndUpdate(id, data) {
  const _id = id.replaceAll('.', '_');
  if ($("td#refdef-ea-" + _id).html() !== '-') {
    return true;
  }
  if (data != null) {
    $("td#refdef-ea-"+_id).html(data.RefE == 0 ? "False":"True");
    $("td#refdef-vd-"+_id).html(data.RefV == 0 ? "False":"True");
    $("td#refdef-ft-"+_id).html(data.RefF == 0 ? "False":"True");
  }
  return false;
}

function getRelationDefinitions(id='27212.3559.31743.2327') {
  const url = SERVER + `entities/${id}/relation-definitions`;
  var output = [];
  if (checkRelationShipAndUpdate(id, null)) {
    return;
  }
  makeGetRequest(url, function (data) {
    console.log("Data obtained : ", data);
    checkRelationShipAndUpdate(id, data);
  }, function (error) {
      console.log(error);
  });
  return;
}

function loadFromChild(entityId) {
  let entityName = clone_datasets.find(e => e.id == entityId);
  if (entityName === undefined) return;
  entityName = entityName.name;
  let _currentType = parentEntities.find(e => e.id == entityId);
  if (_currentType === undefined) return;
  _currentType = _currentType.type;
  console.log(entityName, _currentType);
  $('#div1-parent').fadeOut();
  $('#search').val(entityName);
  currentType = _currentType;
  findBySearch(entityName);
}

function loadTypes() {
  let olds = ["Projekt", "Serienauftrag", "Fahrzeugtyp", "Kunde"];
  function return_span(item) {
    return `<li><a class="dropdown-item" href="#" id="type-${item}">${item}</a></li>`
  }
  const url = SERVER + `entities/types`;
  const typeContentId = "type-list"
  var output = [];
  // $("#" + typeContentId).empty();
  makeGetRequest(url, function (data) {
    if (data.length > 0) {
      $.each(data, function (index, item) {
        if (!olds.includes(item)) {
          $("#" + typeContentId).append(return_span(item));
          output.push(item);
        }
      });
    }
    console.log("Data types entities : ", output);
  }, function (error) {
      console.log(error);
  });
  return;
}

function availableAttributes(entityId) {
  const entity = clone_datasets.find(e => e.id == entityId);
  if (entity === undefined) return;
  const creationInfo = {
    attributeId: "Creation Date",
    value: entity.creationInfo
  };
  const modificationInfo = {
    attributeId: "Modification Date",
    value: entity.modificationInfo
  };

  function return_row_attribute(item) {
    return `<tr id="attribute-row-${item.id}">
            <td> ${item.attributeId} </td>
            <td> ${item.value === "None" ? "-" : item.value} </td>
            </tr>`
  }
  const url = SERVER + `entity-attribute/${entityId}/entity`;
  const attributeContentId = "data-table-attribute-body"
  var output = [];
  $("#" + attributeContentId).empty();
  makeGetRequest(url, function (data) {
    if (data.length > 0) {
      $.each(data, function (index, item) {
          $("#" + attributeContentId).append(return_row_attribute(item));
          output.push(item);
      });
    }
    $("#div3-parent").fadeIn(); // Fades in the div
    console.log("Data attributes entities : ", output);
  }, function (error) {
      console.log(error);
  });
  $("#" + attributeContentId).append(return_row_attribute(creationInfo));
  $("#" + attributeContentId).append(return_row_attribute(modificationInfo));
  return;
}

$(document).ready(function () {
  checkLogin();
  $('#loading-gif').hide();

  $('tbody').scroll(function(e) { 
    $('thead').css("left", -$("tbody").scrollLeft()); //fix the thead relative to the body scrolling
    $('thead th:nth-child(1)').css("left", $("tbody").scrollLeft()); //fix the first cell of the header
    $('tbody td:nth-child(1)').css("left", $("tbody").scrollLeft()); //fix the first column of tdbody
  });

  // const value = localStorage.getItem("SEARCH");
  // $("#search").val(value);
  $("#search").focus();
  // $("#search").on("input", function () {
  //   tracker = {};
  //   var typedValue = $(this).val();
  //   if (typedValue.length > 0) getEntityFilteredNames(typedValue);
  //   else {
  //     $("#entity-proposition-list").empty();
  //     $("#entity-proposition-list").css("display", "none");
  //     // $("#entity-proposition-list").html("<span>No results</span>");
  //   }
  //   // findBySearch(typedValue);
  // });

  $("#search-button").click(function () {
    var typedValue = $("#search").val();
    findBySearch(typedValue);
  });

  $("#exit-button").click(function () {
    logout();
  });

  $("#export-button").click(function () {
    $("#data-table").table2excel({
      name: "Sheet",
      filename: "export-at-" + new Date().getTime() + ".xls",
    });
  });

  $("#file-button").click(function () {
    var url =
      SERVER + "entities/export?ids=" + removeDuplicates(entities).join(";") + "&pfb=" + PFB;
    window.open(url);
    alert("Files downloaded !");
  });

  $(document).on("click", 'button[id^="actiondel-"]', function () {
    $(this)
      .parent()
      .parent()
      .fadeTo(400, 0, function () {
        $(this).remove();
      });
  });

  $(document).on("mouseenter", 'td[id^="refdef-"]', function () {
    const parts = $(this).attr("id").split("-");
    const id = parts[2].replaceAll('_', '.');
    getRelationDefinitions(id);
  });

  $(document).on("click", 'button[id^="actiondownl-"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var entityId = parts[1];
    console.log("Base entity : ", id);
    var url = SERVER + "entities/export?ids=" + entityId + "&pfb=" + PFB;
    window.open(url);
    alert("Files downloaded !");
  });

  $(document).on("click", 'i[id^="i-"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var status = parts[1];
    var entityId = parts[2];
    var output = updateVisibility(status, entityId, datasets);
    datasets = output;
  });

  $(document).on("click", 'i[id^="a-"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var status = 'expand-a';
    var entityId = parts[2];
    var output = updateChildrenVisibility(status, entityId, datasets);
    datasets = output;
  });

  $(document).on("click", 'i[id^="p-"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var status = parts[1];
    var entityId = parts[2];
    getParentEntities(entityId);
  });

  $(document).on("click", 'i[id^="attr-expand-"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var status = parts[1];
    var entityId = parts[2];
    availableAttributes(entityId);
  });

  $(document).on("click", 'i[id^="expand-children"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var status = parts[1];
    var entityId = parts[2];
    searchEntityByEntityId(entityId);
  });

  $(document).on("click", 'i[id^="f-"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var status = parts[1];
    var entityId = parts[2];
    getEntityFiles(entityId); // entityId
  });

  $('#type-free-suche').on("click", function () {
    loadTypes();
  });

  $('#hide-parent-view').on("click", function () {
    $('#div1-parent').fadeOut(); // Fades out the div
  });

  $('#hide-file-view').on("click", function () {
    $('#div2-parent').fadeOut(); // Fades out the div
  });

  $('#hide-attribute-view').on("click", function () {
    $('#div3-parent').fadeOut(); // Fades out the div
  });

  // $('#withoutTS').click("checked", function() {
  //     // alert( $(this).is(":checked") );
  //     withoutTS = $(this).is(":checked");
  // });

  $('#PFB').click("checked", function() {
    // alert( $(this).is(":checked") );
    PFB = $(this).is(":checked");
    const tmpArray = [].concat(clone_datasets);
    if (PFB) {
      // console.log('tmpArray :> ', tmpArray.length);
      // const _data = []
      // const viewed = []
      // for(let i = 0; i < tmpArray.length; i++) {
      //   let entity = tmpArray[i];
      //   if (viewed.includes(entity.id)) continue;
      //   viewed.push(entity.id);
      //   if (entity.type === "Produkt") {
      //     if (entity.stateName === "Freigabe zur Beschaffung") {
      //       console.log('entity :> "Freigabe zur Beschaffung" ', entity);
      //       _data.push(entity);
      //     }
      //   } else {
      //     if (entity.type !== "Produkt") _data.push(entity);
      //   }
      // }
      // console.log('tmpArray after :> ', _data.length, ' viewed ', viewed.length);
      // if (_data.length > 0) {
      //   const clone_data = [].concat(_data);
      //   const __data = extractRoot(clone_data);
      //   console.log("Data PFB: ", __data);
        $("#"+contentId).empty();
        // const clone_data = [].concat(datasets);
        // const __data = extractRoot(clone_data);
        console.log("Datasets : ", PFB, " >>>> ", datasets);
        fillDataTable(datasets);
      // }
    } else {
      // var _datasets = tmpArray;
      $("#"+contentId).empty();
      fillDataTable(datasets);
    }
});

  $('#nav-previous-button').click(function () {
    var typedValue = currentPage.value;
    currentPageNumber--;
    currentPage.page = currentPageNumber;
    if (currentPageNumber < 0) {
      currentPageNumber = 0;
      currentPage.page = currentPageNumber;
      alert('Impossible to go back anymore')
      return;
    } else {
      findBySearch(typedValue);
    }
  });

  $('#nav-next-button').click(function () {
    var typedValue = currentPage.value;
    currentPageNumber++;
    currentPage.page = currentPageNumber;
    findBySearch(typedValue);
  });

  $(document).on("click", 'i[id^="down-expand"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var status = parts[1];
    var entityId = parts[2];
    var file = entityFiles.find(e => e.id == entityId);
    if (file === undefined || file?.localLocationInitial === undefined) return;
    var url = SERVER + "files/export?path=" + file?.localLocationInitial;
    window.open(url);
    alert("File downloaded !");
  });

});
