package com.cenit.Waldaschaff.matrix.webservice.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@javax.persistence.Entity
@Table(name="state")
public class State {

	@Id
	@Column(name="id")
	private Long id;

	@Column(name="entity_id")
	private String entityId;

	@Column(name="name")
	private String name;

	public State(Long id_, String entityId_, String name_)
	{
		this.id = id_;
		this.entityId = entityId_;
		this.name = name_;
	}

	public State() {
		super();
	}
	
}
