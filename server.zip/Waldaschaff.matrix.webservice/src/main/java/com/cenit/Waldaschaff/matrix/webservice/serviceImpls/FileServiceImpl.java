package com.cenit.Waldaschaff.matrix.webservice.serviceImpls;

import com.cenit.Waldaschaff.matrix.webservice.entities.File;
import com.cenit.Waldaschaff.matrix.webservice.repositories.FileRepository;
import com.cenit.Waldaschaff.matrix.webservice.services.FileService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class FileServiceImpl implements FileService {

	FileRepository fileRepository;

	public FileServiceImpl(FileRepository fileRepository) {
		super();
		this.fileRepository = fileRepository;
	}

	@Override
	public File findOneById(String id) {
		// TODO Auto-generated method stub
		return this.fileRepository.findOneById(id);
	}

	@Override
	public ArrayList<File> findByBusId(String busId) {
		return this.fileRepository.findByBusId(busId);
	}

}
