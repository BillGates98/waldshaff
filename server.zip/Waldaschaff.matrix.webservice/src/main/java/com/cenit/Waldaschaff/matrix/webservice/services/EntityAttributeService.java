package com.cenit.Waldaschaff.matrix.webservice.services;

import com.cenit.Waldaschaff.matrix.webservice.entities.EntityAttribute;

import java.util.ArrayList;


public interface EntityAttributeService {
	
	public EntityAttribute findOneById(Long id);

	public ArrayList<EntityAttribute> findByEntityId(String entityId);
}
