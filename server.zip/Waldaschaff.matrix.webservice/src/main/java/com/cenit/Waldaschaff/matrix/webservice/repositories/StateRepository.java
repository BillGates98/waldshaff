package com.cenit.Waldaschaff.matrix.webservice.repositories;

import com.cenit.Waldaschaff.matrix.webservice.entities.State;
import com.cenit.Waldaschaff.matrix.webservice.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface StateRepository extends JpaRepository<State, Long> {
	
	public State findOneById(Long id);

	public ArrayList<State> findByEntityId(String entityId);
}
