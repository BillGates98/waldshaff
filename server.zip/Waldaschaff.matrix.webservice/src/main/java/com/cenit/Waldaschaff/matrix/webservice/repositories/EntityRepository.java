package com.cenit.Waldaschaff.matrix.webservice.repositories;

import com.cenit.Waldaschaff.matrix.webservice.entities.Entity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public interface EntityRepository extends JpaRepository<Entity, Long> {
	
	public Entity findOneById(String id);

	public ArrayList<Entity> findByTypeAndNameStartingWith(String type, String name);

	public ArrayList<Entity> findByTypeContaining(String type);

	@Query(value = "SELECT DISTINCT type FROM entity", nativeQuery = true)
	public ArrayList<String> findTypes();
}
