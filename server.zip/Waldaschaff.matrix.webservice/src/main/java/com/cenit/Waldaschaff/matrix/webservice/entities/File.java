package com.cenit.Waldaschaff.matrix.webservice.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Data
@javax.persistence.Entity
@Table(name="file")
public class File {

	@Id
	@Column(name="id")
	private String id;

	@Column(name="type")
	private String type;

	@Column(name="name")
	private String name;

	@Column(name="revision")
	private String revision;

	@Column(name="format")
	private String format;

	@Column(name="local_location_cleaned")
	private String localLocationCleaned;

	@Column(name="local_location_initial")
	private String localLocationInitial;

	@Column(name="bus_id")
	private String busId;

	@Column(name="filename")
	private String filename;

	@Column(name="filesize")
	private String filesize;

	@Transient
	private int level = 0;


	public File(String id_, String type_, String name_, String revision_, String format_, String localLocationCleaned_, String localLocationInitial_, String busId_, String filename_, String filesize_)
	{
		this.id = id_;
		this.type = type_;
		this.name = name_;
		this.revision = revision_;
		this.format = format_;
		this.localLocationCleaned = localLocationCleaned_;
		this.localLocationInitial = localLocationInitial_;
		this.busId = busId_;
		this.filename = filename_;
		this.filesize = filesize_;
	}

	public File() {
		super();
	}
	
}
