package com.cenit.Waldaschaff.matrix.webservice.services;

import com.cenit.Waldaschaff.matrix.webservice.entities.Auth;
import com.cenit.Waldaschaff.matrix.webservice.entities.Entity;

import java.util.ArrayList;
import java.util.List;


public interface AuthService {
	
	public Auth findOneByUsername(String username);

	public Auth findOneByUsernameAndPassword(String username, String password);

	public Auth findOneByToken(String token);

	public Auth login(Auth user);

	public String logout(String token);
}
