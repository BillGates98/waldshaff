package com.cenit.Waldaschaff.matrix.webservice.services;

import com.cenit.Waldaschaff.matrix.webservice.entities.Entity;
import org.springframework.data.repository.query.Param;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public interface EntityService {
	
	public Entity findOneById(String id);

	public List<Entity> findEntityByStartingWith(String type, String name, boolean wbom, int page);

	public List<Entity> findParentEntityByEntityId(String entityId);

	public ArrayList<Entity> findEntityTree(String id, String direction, String operation);

	public HashMap<String, String> findRelationDefinitions(String entityId);

	public ArrayList<String> findTypes();
}
