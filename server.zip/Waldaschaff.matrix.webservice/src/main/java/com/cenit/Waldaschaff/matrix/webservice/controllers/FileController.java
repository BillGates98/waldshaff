package com.cenit.Waldaschaff.matrix.webservice.controllers;

import com.cenit.Waldaschaff.matrix.webservice.entities.File;
import com.cenit.Waldaschaff.matrix.webservice.services.FileService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

@RestController
@RequestMapping(value="/api/files")
@CrossOrigin(origins = "*")
public class FileController {


	FileService fileService;

	@Value("${downloading.dataPath}")
	String parentPath;

	public FileController(FileService fileService) {
		this.fileService = fileService;
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	HttpEntity<File> fileResource(@PathVariable("id") String id) {
	   File file = this.fileService.findOneById(id);
	   return new ResponseEntity<>(file, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/{id}/entity", method = RequestMethod.GET)
	HttpEntity<Object> entityWithFileResource(@PathVariable("id") String busId) {
		ArrayList<File> files = this.fileService.findByBusId(busId);
		if (files != null) {
            return new ResponseEntity<>(buildPath(files), HttpStatus.OK);
		}
		return new ResponseEntity<>(null, HttpStatus.OK);
	}

	/*
		Downloading section
	 */
	@RequestMapping(value = "/export", method=RequestMethod.GET)
	public ResponseEntity<Resource> getZippedFiles(HttpServletResponse response, @RequestParam("path") String _path) throws IOException {
		System.out.println(_path);
        Path path = Paths.get(_path);
        java.io.File file = path.toFile();

        if (!file.exists()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        Resource resource = new FileSystemResource(file);

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + file.getName());
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);

        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(file.length())
                .body(resource);

    }

	private ArrayList<File> buildPath(ArrayList<File> files) {
		ArrayList<File> data = new ArrayList<>();
		String filename = "";
		for(File file: files) {
			filename = parentPath + file.getLocalLocationCleaned() + "/" + file.getFilename();
			file.setLocalLocationInitial(filename);
			data.add(file);
			// System.out.println("File : " + filename);
		}
		return data;
	}

}
