const SERVER = "http://localhost:8009/api/";

let currentType = "Projekt";
let tracker = {};
let entities = [];

function makeRequest(url, success) {
  if (!url in tracker) {
    tracker[url] = 0;
  }

  if (tracker[url] == 1 && !url.includes("search-by")) {
    return;
  }

  $.ajax({
    url: url,
    method: "GET",
    headers: {
      "Access-Control-Allow-Origin": "*",
    },
    success: function (data) {
      tracker[url] = 1;
      success(data);
    },
    error: function (error) {
      console.error("Request error : " + error.statusText);
    },
  });
}

function makePostRequest(url, data, success) {
  $.post(url, data, null);
}

function searchEntityByName(value) {
  var url =
    SERVER +
    "entities/search-by?type=" +
    currentType +
    "&value={value}".replace("{value}", value);
  makeRequest(url, function (data) {
    var table = $("#table-body");
    table.empty();
    $.each(data, function (index, item) {
      var row = $("<tr id='row-" + item.id.replaceAll(".", "_") + "'>");
      row.append(
        $("<td>").html(
          "<button class='btn btn-light' id='action-" +
            item.id.replaceAll(".", "_") +
            "'>+</button> " +
            item.name
        )
      );
      row.append($("<td>").text(item.revision));
      row.append($("<td>").text(item.type));
      row.append($("<td>").text(item.policyRef));
      row.append($("<td>").text(item.description));
      row.append($("<td>").text(item.vaultRef));
      var buttons =
        "<button class='btn btn-danger' id='actiondel-" +
        item.id.replaceAll(".", "_") +
        "'><span class='glyphicon glyphicon-minus' aria-hidden='true'></span></button>";
      buttons =
        buttons +
        "<button class='btn btn-primary' id='actionmore-" +
        item.id.replaceAll(".", "_") +
        "'><span class='glyphicon glyphicon-grain' aria-hidden='true'></span></button>";
      row.append($("<td style='width: 100px'>").html(buttons));
      table.append(row);
      entities.push(item.id); // entities for the downloading
    });
  });
}

function searchRelationShips(parentId, entityId) {
  parentId = "#data-table " + "#" + parentId;
  var url =
    SERVER + "entities/{value}/relationships".replace("{value}", entityId);
  makeRequest(url, function (data) {
    var targetRow = $(parentId);

    $.each(data.relationships, function (index, item) {
      var row = $("<tr id='row-" + parentId + "'>");
      row.append(
        $("<td>").html(
          "<button class='btn btn-light' id='action-" +
            item.id.replaceAll(".", "_") +
            "'>+</button> " +
            item.name
        )
      );
      row.append($("<td>").text(item.revision));
      row.append($("<td>").text(item.type));
      row.append($("<td>").text(item.relDefRef));
      row.append($("<td>").text(item.kind));
      row.append($("<td>").text(item.vaultRef));
      var buttons =
        "<button class='btn btn-danger' id='actiondel-" +
        item.id.replaceAll(".", "_") +
        "'><span class='glyphicon glyphicon-minus' aria-hidden='true'></span></button>";
      buttons =
        buttons +
        "<button class='btn btn-primary' id='actionmore-" +
        item.id.replaceAll(".", "_") +
        "'><span class='glyphicon glyphicon-grain' aria-hidden='true'></span></button>";
      row.append($("<td style='width: 100px'>").html(buttons));
      row.insertAfter(targetRow);
    });
  });
}

/**
 * Actions space */

function removeFromSet(element, list) {
  output = [];
  for (const elt of list) {
    if (!(element == elt)) {
      output.push(elt);
    }
  }
  return output;
}

function removeDuplicates(arr) {
  let unique = arr.reduce(function (acc, curr) {
    if (!acc.includes(curr)) acc.push(curr);
    return acc;
  }, []);
  return unique;
}

$(document).on("click", 'button[id^="actiondel-"]', function () {
  $(this)
    .parent()
    .parent()
    .fadeTo(400, 0, function () {
      $(this).remove();
      let id = $(this).attr("id");
      id = id.replace("row-", "").replaceAll("_", ".");
      entities = removeFromSet(id, entities);
    });
});

$(document).on("click", 'button[id^="action-"]', function () {
  var buttonId = $(this).attr("id");
  var id = buttonId.split("-")[1].replaceAll("_", ".");
  var parentId = $(this).parent().parent().attr("id");
  searchRelationShips(parentId, id);
});

// $('#myTableRow').remove();

$(document).on("click", 'a[id^="type-"]', function () {
  var dropDownId = $(this).attr("id");
  var id = dropDownId.replace("type-", "");
  currentType = id;
  $("#current-type").text(id);
});

function findBySearch(value) {
  if (value.length) {
    searchEntityByName(value);
  }
}

$(document).ready(function () {
  const organisationData = [
    { tt_key: 1, tt_parent: 0, name: "CEO" },
    { tt_key: 2, tt_parent: 1, name: "CTO" },
    { tt_key: 3, tt_parent: 2, name: "developer" },
    { tt_key: 5, tt_parent: 3, name: "developer 1" },
    { tt_key: 4, tt_parent: 1, name: "CFO" },
  ];

  $("#data-table").treeTable({
    data: organisationData,
    columns: [
      {
        data: "name",
      },
    ],
  });

  $("#search").on("input", function () {
    tracker = {};
    var typedValue = $(this).val();
    findBySearch(typedValue);
  });

  $("#search-button").click(function () {
    var typedValue = $("#search").val();
    findBySearch(typedValue);
  });

  $("#export-button").click(function () {
    $("#data-table").table2excel({
      name: "Sheet",
      filename: "export-at-" + new Date().getTime() + ".xls",
    });
  });

  $("#file-button").click(function () {
    console.log();

    var url =
      SERVER + "entities/export?ids=" + removeDuplicates(entities).join(";");
    console.log(url);
    window.open(url);
    alert("Files downloaded !");
  });
});
