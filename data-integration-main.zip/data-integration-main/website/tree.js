var contentId = "data-table-body";
function depth_structure(entity, data) {
  if (!("children" in entity)) {
    entity.children = [];
  }
  for (var i = 0; i < data.length; i++) {
    if (
      data[i].parentEntityId === entity.id &&
      entity.level + 1 == data[i].level
    ) {
      if (entity.show === false) {
        data[i].show = false;
      }
      entity.children.push(depth_structure(data[i], data));
    }
  }
  return entity;
}

function extractRoot(data) {
  var output = [];
  for (var i = 0; i < data.length; i++) {
    if (data[i].level === 0) {
      output.push(depth_structure(data[i], data));
    }
  }
  return output;
}

function count_space(level) {
  var output = "";
  for (var i = 0; i < 5 * level; i++) {
    output += "\t";
  }
  return output;
}

function return_table_row(entity, id) {
  if (id != null && entity.id === id) {
    entity.show = !entity.show;
    for (var i = 0; i < entity.children.length; i++) {
      entity.children[i].show = !entity.show;
    }
  }

  if (entity.id !== id && entity.show == false && entity.level > 0) {
    return "";
  }
  var filename = entity.id;
  const button =
    "<button title='Export' class='btn btn-secondary' id='actiondownl-" +
    filename +
    "'><i class='bi bi-cloud-download'></i></button>";

  const expandButton = `<i class="bi bi-caret-right-fill" id="i-expand-${entity?.id}"></i>`;
  const collapseButton = `<i class="bi bi-caret-down-fill" id="i-collapse-${entity?.id}"></i>`;
  return `<tr id="${entity.id}">
            <td style="padding-left: ${(3 + entity?.level) * 10}px"> ${
    entity?.show === true ? expandButton : collapseButton
  } ${entity?.name + ""} (${entity?.children.length})</td>
            <td> ${entity?.revision + ""} </td>
            <td> ${entity?.type + ""} </td>
            <td> ${entity?.policyRef + ""} </td>
            <td> ${entity?.relDefRef + ""}</td>
            <td> ${entity?.kind + ""} </td>
            <td> ${entity?.vaultRef + ""}</td>
            <td> ${button} </td>
        </tr>`;
}

function showEntityRow(entity, id) {
  var out = return_table_row(entity, id);
  if (out != "") {
    $("#" + contentId).append(out);
  }

  for (var i = 0; i < entity.children.length; i++) {
    showEntityRow(entity.children[i], id);
  }
}

function showDataTable(data, id) {
  var tree = extractRoot(data);
  for (var i = 0; i < tree.length; i++) {
    showEntityRow(tree[i], id);
  }
}

// showDataTable(dataSet);

function updateVisibility(id, data) {
  $("#" + contentId).empty();

  for (var i = 0; i < data.length; i++) {
    if (data[i].id === id) {
      data[i].show = !data[i].show;
    }
    data[i].children = [];
  }
  showDataTable(data, id);
  return data;
}
