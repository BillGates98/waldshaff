const SERVER = "http://localhost:8009/api/";

// let currentType = "Projekt";
let currentType = "Projektstufe";
// let currentType = "CATProduct";
let tracker = {};
let entities = [];
let oldTextLength = 0;

let datasets = [];

function makeRequest(url, success) {
  if (!url in tracker) {
    tracker[url] = 0;
  }

  if (tracker[url] == 1 && !url.includes("search-by")) {
    return;
  }

  $.ajax({
    url: url,
    method: "GET",
    headers: {
      "Access-Control-Allow-Origin": "*",
    },
    success: function (data) {
      success(data);
      console.log(data);
    },
    error: function (error) {
      console.error("Request error : " + error.statusText);
    },
  });
}

function makePostRequest(url, data, success) {
  $.post(url, data, null);
}

function searchEntityByName(value) {
  var url =
    SERVER +
    "entities/search-by?type=" +
    currentType +
    "&value={value}".replace("{value}", value);

  makeRequest(url, function (data) {
    datasets = [];
    if (data.length > 0) {
      $.each(data, function (index, item) {
        item.tt_key = item.id;
        item.tt_parent = item.parentEntityId ? item.parentEntityId : 0;
        if (!item.relDefRef) item.relDefRef = "";
        if (!item.kind) item.kind = "";
        if (!item.policyRef) item.policyRef = "";
        if (item.level < 4) item.show = true;
        else item.show = false;

        item.old_show = item.show;
        datasets.push(item);
        entities.push(item.id);
      });
    }
    console.log("Data tree : ", datasets);
    fillDataTable(datasets);
  });
}

/**
 * Actions space */

function removeFromSet(element, list) {
  output = [];
  for (const elt of list) {
    if (!(element == elt)) {
      output.push(elt);
    }
  }
  return output;
}

function removeDuplicates(arr) {
  let unique = arr.reduce(function (acc, curr) {
    if (!acc.includes(curr)) acc.push(curr);
    return acc;
  }, []);
  return unique;
}

$(document).on("click", 'a[id^="type-"]', function () {
  var dropDownId = $(this).attr("id");
  var id = dropDownId.replace("type-", "");
  currentType = id;
  $("#current-type").text(id);
});

function findBySearch(value) {
  if (value.length > 0) {
    localStorage.setItem("SEARCH", value);
    searchEntityByName(value);
  }
}

function fillDataTable(dataset) {
  showDataTable(dataset, null);
}

$(document).ready(function () {
  const value = localStorage.getItem("SEARCH");
  $("#search").val(value);
  $("#search").focus();
  $("#search").on("input", function () {
    tracker = {};
    var typedValue = $(this).val();
    findBySearch(typedValue);
  });

  $("#search-button").click(function () {
    var typedValue = $("#search").val();
    findBySearch(typedValue);
  });

  $("#export-button").click(function () {
    $("#data-table").table2excel({
      name: "Sheet",
      filename: "export-at-" + new Date().getTime() + ".xls",
    });
  });

  $("#file-button").click(function () {
    var url =
      SERVER + "entities/export?ids=" + removeDuplicates(entities).join(";");
    window.open(url);
    alert("Files downloaded !");
  });

  $(document).on("click", 'button[id^="actiondel-"]', function () {
    $(this)
      .parent()
      .parent()
      .fadeTo(400, 0, function () {
        $(this).remove();
      });
  });

  $(document).on("click", 'button[id^="actiondownl-"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var entityId = parts[1];
    console.log("Base entity : ", id);
    var url = SERVER + "entities/export?ids=" + entityId;
    window.open(url);
    alert("Files downloaded !");
  });

  $(document).on("click", 'i[id^="i-"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var entityId = parts[2];
    var output = updateVisibility(entityId, datasets);
    datasets = output;
  });
});
