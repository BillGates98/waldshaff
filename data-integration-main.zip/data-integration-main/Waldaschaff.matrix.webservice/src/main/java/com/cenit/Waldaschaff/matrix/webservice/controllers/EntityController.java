package com.cenit.Waldaschaff.matrix.webservice.controllers;

import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.cenit.Waldaschaff.matrix.webservice.models.DownZip;
import com.cenit.Waldaschaff.matrix.webservice.models.FileZipper;
import com.cenit.Waldaschaff.matrix.webservice.services.FileZippingService;
import net.bytebuddy.asm.Advice;
import org.apache.catalina.connector.Response;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.bind.annotation.*;

import com.cenit.Waldaschaff.matrix.webservice.entities.Entity;
import com.cenit.Waldaschaff.matrix.webservice.entities.Relationship;
import com.cenit.Waldaschaff.matrix.webservice.services.EntityService;
import com.cenit.Waldaschaff.matrix.webservice.services.RelationshipService;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import javax.servlet.http.HttpServletResponse;

@Controller
@RequestMapping(value="/api/entities")
@CrossOrigin(value = "*")
public class EntityController {

	
	EntityService entityService;
	RelationshipService relationshipService;
	@Value("${downloading.dataPath}")
	String parentPath;

	public EntityController(EntityService entityService, RelationshipService relationshipService) {
		this.entityService = entityService;
		this.relationshipService = relationshipService;
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	HttpEntity<Entity> entityResource(@PathVariable("id") String id) {
	   Entity entity = this.entityService.findOneById(id);
	   return new ResponseEntity<>(entity, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/{id}/relationships", method = RequestMethod.GET)
	HttpEntity<Object> entityWithRelationshipResource(@PathVariable("id") String id) {
		ArrayList<Entity> data = new ArrayList<>();
		Entity entity = this.entityService.findOneById(id);
		if (entity != null) {
			data.add(entity);
			ArrayList<Entity> results = this.entityService.findEntityTree(entity.getId());
			if (results != null && !results.isEmpty()) {
				data.addAll(results);
			}
			return new ResponseEntity<>(data, HttpStatus.OK);
		}
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	@RequestMapping(value = "/search-by", method = RequestMethod.GET)
	HttpEntity<Object> entityByName(@RequestParam("type") String type,
									@RequestParam("value") String value) {
		System.out.println(" field : " + type + " value : " + value);
		List<Entity> data = this.entityService.findEntityByContaining(type, value);
		return new ResponseEntity<>(data, HttpStatus.OK);
	}

	/*
		Downloading section
	 */
	@RequestMapping(value = "/export", method=RequestMethod.GET, produces="application/zip")
	public void getZippedFiles(HttpServletResponse response, @RequestParam("ids") String entities) throws IOException {
		Object[] entityIds = Arrays.stream(entities.split(";")).toArray();
		ArrayList<Entity> entitiesTree = new ArrayList<>();
		ArrayList<String> selectedFiles = new ArrayList<>();
		for(Object value : entityIds) {
			System.out.println(value);
			entitiesTree = this.entityService.findEntityTree((String) value);
			System.out.println("Total of " + entitiesTree.size() + " elements !");
			for(Entity entity: entitiesTree) {
				if (entity.getPath() != null && !entity.getPath().isEmpty()) {
					ArrayList<String> currentFiles = listFilesForFolder(parentPath + entity.getPath());
					if (currentFiles != null && !currentFiles.isEmpty() && !selectedFiles.containsAll(currentFiles)) {
						System.out.println(" E >> " + parentPath + entity.getPath());
						selectedFiles.addAll(currentFiles);
					}
				}
			}
		}

		// add the tree text file
		selectedFiles.add(parentPath + "Compressed/treeText.txt");
		String filename = "Compressed_" + System.currentTimeMillis();
		String hintFile = filename + ".zip";
		response.setStatus(HttpServletResponse.SC_OK);
		response.addHeader("Content-Disposition", "attachment; filename=\"" + hintFile + "\"");
		// FileZippingService.zipExportFile(response.getOutputStream(), selectedFiles);
		// clean and copy files to CAD and NON-CAD then
		preparation(selectedFiles);
		FileZippingService.zipExportDirectory(parentPath, response.getOutputStream());
	}

	public ArrayList<String> listFilesForFolder(final String folder) {
		File _folder = new File(folder);
		ArrayList<String> selectedFiles = new ArrayList<>();
		for (final File fileEntry : Objects.requireNonNull(_folder.listFiles())) {
			selectedFiles.add(fileEntry.getPath());
		}
		return selectedFiles;
	}

	public void preparation(ArrayList<String> files) {
		String cad = parentPath + "Compressed/CAD/";
		String nonCad = parentPath + "Compressed/non-CAD/";
		int subDirCount = 2;

		File fCad = new File(cad);
		File fNonCad = new File(nonCad);
        try {
			FileUtils.deleteDirectory(fCad);
            if(!fCad.exists()) {
				FileUtils.forceMkdir(fCad);
				for(int i = 1; i <= subDirCount; i++) {
					FileUtils.forceMkdir(new File(fCad.getAbsolutePath() + "/" + i));
				}
			}
			FileUtils.deleteDirectory(fNonCad);
			if(!fNonCad.exists()) {
				FileUtils.forceMkdir(fNonCad);
				for(int i = 1; i <= subDirCount; i++) {
					FileUtils.forceMkdir(new File(fNonCad.getAbsolutePath() + "/" + i));
				}
			}
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

		for(String file: files) {
			File _file = new File(file);
            try {
				System.out.println(file);
				copyFile(_file.getPath(), fCad.getPath() + "/1/");
				copyFile(_file.getPath(), fNonCad.getPath() + "/1/");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

	public void copyFile(String sourceFilePath, String destinationDirectoryPath) throws IOException {
		File sourceFile = new File(sourceFilePath);
		File destinationDirectory = new File(destinationDirectoryPath);

		// Check if the source file exists
		if (!sourceFile.exists()) {
			throw new FileNotFoundException("Source file not found: " + sourceFilePath);
		}

		// Check if the destination directory exists and create it if it doesn't
		if (!destinationDirectory.exists()) {
			if (!destinationDirectory.mkdirs()) {
				throw new IOException("Failed to create destination directory: " + destinationDirectoryPath);
			}
		}

		// Get the filename from the source file path
		String fileName = sourceFile.getName();

		// Create the destination file path by combining the destination directory path and filename
		String destinationFilePath = destinationDirectoryPath + File.separator + fileName;

		// Copy the file using FileChannel
		try (FileChannel sourceChannel = new FileInputStream(sourceFile).getChannel();
			 FileChannel destinationChannel = new FileOutputStream(destinationFilePath).getChannel()) {
			sourceChannel.transferTo(0, sourceFile.length(), destinationChannel);
		}

		// System.out.println("File copied successfully: " + sourceFilePath + " to " + destinationFilePath);
	}


}
