from html import entities
import xmltodict
from  .compute_files import ComputeFile
import multiprocessing

class XMLParser:
    
    def __init__(self, input_path=''):
        print('Parser')
        self.xmls = []
        self.input_path = input_path
        files = ComputeFile(input_path=input_path).build_list_files()
        for input_file in files :
            with open(input_file) as xmlfile:
                self.xmls.append((input_file, xmltodict.parse(xmlfile.read())))
                
    def split_arrays(self, a = [], n=16):
        k, m = divmod(len(a), n)
        return (a[i*k+min(i, m):(i+1)*k+min(i+1, m)] for i in range(n))
             
    def convert(self):
        return self.split_arrays(a=self.xmls)
    
    def run(self):
        return self.convert()
        
# XMLParser(input_path='./data/').run()