

from packages.migrator import Migrator


class Attribute:
    
    def __init__(self, data={}, migrator: Migrator=None):
        self.data = data
        self.migrator = migrator
    
    def save(self):
        data = self.data
        id = self.migrator.fetchBy(table="attribute", field='name', _value=data['name'], result_value="id")
        if id : 
            return id
        query = """
            INSERT INTO attribute 
            ('name', 'value_type')
            VALUES ("_name", "_vtype")
        """
        query = query.replace("'", '`')
        id = self.migrator.fetchBy(table="attribute", field='name', _value=data['name'], result_value="id")
        if id :
            return id
        else:
            for key in ['name']:
                if '_' + key in query :
                    query = query.replace('_' + key, str(data[key]))
            types = ['string', 'integer', 'unknown']
            for type in types:
                if type in data: 
                    query = query.replace('_vtype', str(type))
                    break
            # print(query)
            self.migrator.create(query=query)
            id = self.migrator.fetchBy(table="attribute", field='name', _value=data['name'], result_value="id")
            # print('attribute *********** ', data['name'], '------', id)
            return id
        