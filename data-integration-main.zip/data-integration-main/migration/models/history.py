

from packages.migrator import Migrator


class History:
    
    def __init__(self, data={}, entityId='', migrator: Migrator=None):
        self.data = data
        if 'toObject' in data :
            self.data['objectType'] = data['toObject']['businessObjectRef']['objectType']
            self.data['objectName'] = data['toObject']['businessObjectRef']['objectName']
        self.entityId = entityId
        self.migrator = migrator
        
    def save(self):
        data = self.data
        # datetime, agent, event, stateName, relationshipName, 
        # objectType, objectName
        query = """
            INSERT INTO history 
            ('id', 'agent', 'event', 'stateName', 'relationshipName', 'objectType' ,'objectName', 'datetime') 
            VALUES (0, "_agent", "_event", "_stateName", "_relationshipName", "_objectType", "_objectName",  "_datetime")
        """
        query = query.replace("'", '`')
        keys = ["agent", "event", "stateName", "relationshipName", "objectType", "objectName",  "datetime"]
        for hkey in keys :
            if hkey in data:
                query = query.replace('_' + hkey, str(data[hkey]))
            else:
                query = query.replace('_' + hkey, "")
        
        # print(query)
        self.migrator.create(query=query)
        return None
       
        