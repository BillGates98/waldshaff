

from packages.migrator import Migrator


class Entity:

    def __init__(self, data={}, migrator: Migrator = None):
        if data:
            print('Entity : ', data['@id'])
            self.data = data
            self.data['owner'] = data['owner']['userRef']
            self.data['creationInfo'] = data['creationInfo']['datetime']
            self.data['modificationInfo'] = data['modificationInfo']['datetime']
        self.migrator = migrator

    def save(self):
        data = self.data
        id = self.migrator.fetchBy(
            table="entity", field='id', _value=data['@id'], result_value="id")
        if id:
            return id
        query = """
            INSERT INTO entity 
            ('id', 'type', 'name', 'revision', 'description', 'policy_ref' ,'owner', 'creation_info', 'modification_info', 'current_state', 'vault_ref', 'path', 'format', 'filename', 'parent_entity_id') 
            VALUES ("_@id", "_objectType", "_objectName", "_objectRevision", "_description", "_policyRef", "_owner",  "_creationInfo", "_modificationInfo", "", "", "", "", "", "")
        """
        query = query.replace("'", '`')
        for key in data:
            if '_' + key in query:
                query = query.replace('_' + key, str(data[key]))
        self.migrator.create(query=query)

        return data['@id']

    def update(self, field="", value="", id=""):
        result = self.migrator.update(
            table="entity", field=field, value=value, id=str(id))
        return True if result == 0 else False
