

from packages.migrator import Migrator


class EntityAttribute:
    
    def __init__(self, data={}, migrator: Migrator=None):
        self.data = data
        self.migrator = migrator
    
    def save(self):
        data = self.data
        query = """
            INSERT INTO entity_attribute 
            ('entity_type', 'entity_id', 'attribute_id', 'value') 
            VALUES ("_entity_type", "_entity_id", "_attribute_id", "_value")
        """
        query = query.replace("'", '`')
        for key in data:
            if '_' + key in query :
                query = query.replace('_' + key, str(data[key]))
        self.migrator.create(query=query)
        return 0
        