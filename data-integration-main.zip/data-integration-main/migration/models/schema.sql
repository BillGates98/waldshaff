-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : Dim 14 mai 2023 à 22:03
-- Version du serveur :  10.3.38-MariaDB-0ubuntu0.20.04.1
-- Version de PHP : 7.4.3-4ubuntu2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `data_integration`
--

-- --------------------------------------------------------

--
-- Structure de la table `attribute`
--

CREATE TABLE `attribute` (
  `id` bigint(30) NOT NULL,
  `name` text NOT NULL,
  `value_type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_german2_ci;

-- --------------------------------------------------------

--
-- Structure de la table `computation`
--

CREATE TABLE `computation` (
  `id` bigint(30) NOT NULL,
  `source` text NOT NULL,
  `source_weight` double NOT NULL,
  `target` text NOT NULL,
  `target_weight` double NOT NULL,
  `residual_weight` double NOT NULL,
  `distance` double NOT NULL,
  `gravitational_force` double NOT NULL,
  `class` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_german2_ci;

-- --------------------------------------------------------

--
-- Structure de la table `entity`
--

CREATE TABLE `entity` (
  `id` text NOT NULL,
  `type` text DEFAULT NULL,
  `name` text DEFAULT NULL,
  `revision` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `policy_ref` text NOT NULL,
  `owner` text DEFAULT NULL,
  `creation_info` text DEFAULT NULL,
  `modification_info` text DEFAULT NULL,
  `current_state` text DEFAULT NULL,
  `vault_ref` text DEFAULT NULL,
  `path` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_german2_ci;

-- --------------------------------------------------------

--
-- Structure de la table `entity_attribute`
--

CREATE TABLE `entity_attribute` (
  `id` bigint(30) NOT NULL,
  `entity_type` varchar(50) NOT NULL,
  `entity_id` text NOT NULL,
  `attribute_id` text NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_german2_ci;

-- --------------------------------------------------------

--
-- Structure de la table `history`
--

CREATE TABLE `history` (
  `id` bigint(30) NOT NULL,
  `agent` text NOT NULL,
  `event` text NOT NULL,
  `stateName` text NOT NULL,
  `relationshipName` text NOT NULL,
  `objectType` text NOT NULL,
  `objectName` text NOT NULL,
  `datetime` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_german2_ci;

-- --------------------------------------------------------

--
-- Structure de la table `relationship`
--

CREATE TABLE `relationship` (
  `id` bigint(30) NOT NULL,
  `entity_id` text NOT NULL,
  `type` text NOT NULL,
  `name` text NOT NULL,
  `revision` text NOT NULL,
  `rel_def_ref` text NOT NULL,
  `kind` text NOT NULL,
  `vault_ref` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_german2_ci;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` bigint(30) NOT NULL,
  `ref` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_german2_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `attribute`
--
ALTER TABLE `attribute`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `computation`
--
ALTER TABLE `computation`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `entity_attribute`
--
ALTER TABLE `entity_attribute`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `relationship`
--
ALTER TABLE `relationship`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_ref_unique` (`ref`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `attribute`
--
ALTER TABLE `attribute`
  MODIFY `id` bigint(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `computation`
--
ALTER TABLE `computation`
  MODIFY `id` bigint(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `entity_attribute`
--
ALTER TABLE `entity_attribute`
  MODIFY `id` bigint(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `history`
--
ALTER TABLE `history`
  MODIFY `id` bigint(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `relationship`
--
ALTER TABLE `relationship`
  MODIFY `id` bigint(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` bigint(30) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
