

from packages.migrator import Migrator


class User:
    
    def __init__(self, data={}, migrator: Migrator=None):
        self.data = data
        self.data['owner'] = data['owner']
        self.migrator = migrator
    
    def save(self):
        data = self.data
        query = """
            INSERT INTO user 
            ('ref') 
            VALUES ("_owner")
        """
        query = query.replace("'", '`')
        id = self.migrator.fetchBy(table="user", field='ref', _value=data['owner'], result_value="id")
        if id : 
            return id
        else:
            for key in ['owner']:
                if '_' + key in query :
                    query = query.replace('_' + key, str(data[key]))
            self.migrator.create(query=query)
            id = self.migrator.fetchBy(table="user", field='ref', _value=data['owner'], result_value="id")
            return id 
        