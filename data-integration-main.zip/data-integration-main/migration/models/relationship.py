

from packages.migrator import Migrator


class RelationShip:

    def __init__(self, data={}, kind="", migrator: Migrator = None):
        # print('Relationship : ', kind)
        self.data = data
        self.kind = kind
        self.migrator = migrator

    def save(self, entity_id=""):
        data = self.data
        # id = self.migrator.fetchBy(table="relationship", field='id', _value=data['@id'], result_value="id")
        # if id :
        #     return id
        query = """
            INSERT INTO relationship 
            ('parent_entity_id', 'type', 'name', 'revision', 'rel_def_ref' ,'kind', 'vault_ref', 'child_entity_id') 
            VALUES ("_entityId", "_type", "_name", "_revision", "_rel_def_ref", "_kind", "_vault_ref", "0")
        """
        query = query.replace("'", '`')
        query = query.replace('_entityId', str(entity_id))
        query = query.replace('_type', str(
            data['relatedObject']['businessObjectRef']['objectType']))
        query = query.replace('_name', str(
            data['relatedObject']['businessObjectRef']['objectName']))
        query = query.replace('_revision', str(
            data['relatedObject']['businessObjectRef']['objectRevision']))
        query = query.replace('_rel_def_ref', str(data['relationshipDefRef']))
        query = query.replace('_kind', str(self.kind))
        query = query.replace('_vault_ref', str(
            data['relatedObject']['businessObjectRef']['vaultRef']))
        self.migrator.create(query=query)
        # print(f"{query}")
        return 0

    def update(self, field="", value="", id=""):
        result = self.migrator.update(
            table="relationship", field=field, value=value, id=str(id))
        return True if result == 0 else False
