import pandas as pd
from models.entity import Entity
from packages.migrator import Migrator
from tqdm import tqdm

migrator = Migrator()

data = pd.read_csv('./data/connection/entity_entity.csv', index_col=None)

for index, row in tqdm(data.iterrows()):
    parentEntityId = row[0]
    childEntityId = row[1]
    # print(entityId, parentEntityId)
    result = Entity(migrator=migrator).update(
        field="parent_entity_id", value=parentEntityId, id=childEntityId)
    # print(f"Result status : {result}")
    # exit()

print('Done with success !')
