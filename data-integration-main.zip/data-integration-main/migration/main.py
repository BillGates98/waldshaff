import json
from models.attribute import Attribute

from models.entity import Entity
from models.entity_attribute import EntityAttribute
from models.history import History
from models.relationship import RelationShip
from models.user import User
from packages.migrator import Migrator
from packages.xmlparser import XMLParser
import os
import shutil
import argparse


def get_attribute_value(data={}):
    types = ['string', 'integer', 'unknown']
    output = 'null'
    for type in types:
        if type in data:
            output = data[type]
            break
    return output


def move_proceed_file(input='', input_path='', output_path=''):
    # os.rename(input, input.replace('enqueue', 'proceed'))
    # os.replace(input, input.replace('enqueue', 'proceed'))
    shutil.move(input, input.replace(input_path, output_path))


def migrate(input_path='', output_path=''):
    migrator = Migrator()
    xmls_parseds = XMLParser(input_path=input_path).run()
    # exit()
    for bloc_xml in xmls_parseds:
        # parallelisme
        for file, bloc in bloc_xml:
            print('Running file : ', file)
            if not 'businessObject' in bloc['ematrix']:
                continue
            data = bloc['ematrix']['businessObject']

            # 1. Business object
            entity = Entity(data=data, migrator=migrator)
            entity_id = entity.save()  # save entity and get id
            print("Entity id", entity_id)
            user = User(data=data, migrator=migrator)
            user_id = user.save()  # save user and get id
            print("User id", user_id)
            # update link between entity and user
            entity.update(field="owner", value=user_id, id=entity_id)

            #  2. Entity Attributes list {} : [{}]
            if 'attributeList' in data:
                if int(data['attributeList']['@count']) == 1:
                    data['attributeList']['attribute'] = [
                        data['attributeList']['attribute']]
                for v_attribute in data['attributeList']['attribute']:
                    attribute = Attribute(data=v_attribute, migrator=migrator)
                    attribute_id = attribute.save()
                    sub_data = {
                        'entity_type': data['objectType'],
                        'entity_id': entity_id,
                        'attribute_id': attribute_id,
                        'value': get_attribute_value(data=v_attribute)
                    }
                    entity_attribute = EntityAttribute(
                        data=sub_data, migrator=migrator)
                    entity_attribute_id = entity_attribute.save()

            # 3. From relations list
            if 'fromRelationshipList' in data:
                if int(data['fromRelationshipList']['@count']) == 1:
                    data['fromRelationshipList']['relationship'] = [
                        data['fromRelationshipList']['relationship']]
                print('Relationship gooood ', len(
                    data['fromRelationshipList']['relationship']))
                for relationship in data['fromRelationshipList']['relationship']:
                    relationship = RelationShip(
                        data=relationship, kind="from", migrator=migrator)
                    relationship.save(entity_id=entity_id)

            # 4. To relations list
            if 'toRelationshipList' in data:
                if int(data['toRelationshipList']['@count']) == 1:
                    data['toRelationshipList']['relationship'] = [
                        data['toRelationshipList']['relationship']]
                for relationship in data['toRelationshipList']['relationship']:
                    relationship = RelationShip(
                        data=relationship, kind="to", migrator=migrator)
                    relationship.save(entity_id=entity_id)

            # 5. History List
            if 'historyList' in data:
                if int(data['historyList']['@count']) == 1:
                    data['historyList']['history'] = [
                        data['historyList']['history']]
                for history in data['historyList']['history']:
                    history = History(data=history, migrator=migrator)
                    history.save()
            # exit()
            # move file to proceed directory
            move_proceed_file(input=file, input_path=input_path,
                              output_path=output_path)
            # json_formatted_str = json.dumps(data, indent=2)
            # print(json_formatted_str)
            # exit()


if __name__ == '__main__':

    def get_args():
        parser = argparse.ArgumentParser()
        parser.add_argument(
            '-i', '--input_path', default='./data/proceed/', help='input path')
        parser.add_argument(
            '-o', '--output_path', default='./data/enqueue/', help='output path')

    args = get_args()
    migrate(input_path=args.input, output_path=args.output)
