import os
import time


class RemoveSpecificFile:

    def __init__(self, directory=None) -> None:
        print('Specific file remover started !')
        self.directory = directory
        self.extensions = ['.pdf']

    def look_and_delete(self):
        for parent, dirnames, filenames in os.walk(self.directory):
            for fn in filenames:
                filtered = [os.path.join(
                    parent, fn) for ext in self.extensions if fn.lower().endswith(ext)]
                for file in filtered:
                    os.remove(file)
                    print(f" * {file} has been deleted !")
        return None

    def infinite_loop(self):
        while True:
            time.sleep(5)
            self.look_and_delete()
        return None


RemoveSpecificFile(directory='./source/').infinite_loop()
