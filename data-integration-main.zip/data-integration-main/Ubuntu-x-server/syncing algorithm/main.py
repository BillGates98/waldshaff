from dirsync import sync

from datetime import datetime
from pytz import timezone
from datetime import time


def sync_directories():
    source_path = './source'
    target_path = '/media/bill/Crucial X8/Backup/Plasmaairdaten/Plasmaairdaten/Projekte'
    sync(source_path, target_path, 'sync')
    sync(target_path, source_path, 'sync')


def time_call():
    f = '%H:%M:%S'
    now_time = datetime.now(timezone('Europe/Berlin'))
    IST = now_time.strftime(f)
    ist = str(IST)
    set_time = time(hour=00, minute=33, second=0)
    stime = str(set_time)
    # print(ist)
    if ist == stime:
        print('y')
        print('Current Time :', IST)
        print('Set Time :', set_time)
        sync_directories()


while True:
    time_call()
