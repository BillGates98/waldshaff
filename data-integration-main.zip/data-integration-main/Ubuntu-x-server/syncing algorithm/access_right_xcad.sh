
useradd $1 -G xcad

smbpasswd -a $1

service smbd restart

