
useradd $1 -G plasmaairdatenz

smbpasswd -a $1

service smbd restart