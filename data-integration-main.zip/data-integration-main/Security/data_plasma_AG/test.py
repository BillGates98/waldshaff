print('lol')
