const SERVER = "https://3948-46-193-7-213.ngrok-free.app/api/";

// let currentType = "Projekt";
let currentType = "Projektstufe";
// let currentType = "CATProduct";
let tracker = {};
let entities = [];
let oldTextLength = 0;

let dataTable;

function makeRequest(url, success) {
  if (!url in tracker) {
    tracker[url] = 0;
  }

  if (tracker[url] == 1 && !url.includes("search-by")) {
    return;
  }

  $.ajax({
    url: url,
    method: "GET",
    headers: {
      "Access-Control-Allow-Origin": "*",
    },
    success: function (data) {
      // tracker[url] = 1;
      success(data);
      console.log(data);
    },
    error: function (error) {
      console.error("Request error : " + error.statusText);
    },
  });
}

function makePostRequest(url, data, success) {
  $.post(url, data, null);
}

function searchEntityByName(value) {
  var url =
    SERVER +
    "entities/search-by?type=" +
    currentType +
    "&value={value}".replace("{value}", value);

  makeRequest(url, function (data) {
    let dataTree = [];
    if (data.length > 0) {
      console.log("Data : ", data);
      $.each(data, function (index, item) {
        item.tt_key = item.id;
        item.tt_parent = item.parentEntityId ? item.parentEntityId : 0;
        if (!item.relDefRef) item.relDefRef = "";
        if (!item.kind) item.kind = "";
        if (!item.policyRef) item.policyRef = "";
        dataTree.push(item);
        entities.push(item.id); // entities for the downloading
      });
    }
    fillDataTable(dataTree);
    // localStorage.setItem("DATA", JSON.stringify(dataTree));
    // location.reload();
  });
}

/**
 * Actions space */

function removeFromSet(element, list) {
  output = [];
  for (const elt of list) {
    if (!(element == elt)) {
      output.push(elt);
    }
  }
  return output;
}

function removeDuplicates(arr) {
  let unique = arr.reduce(function (acc, curr) {
    if (!acc.includes(curr)) acc.push(curr);
    return acc;
  }, []);
  return unique;
}

$(document).on("click", 'a[id^="type-"]', function () {
  var dropDownId = $(this).attr("id");
  var id = dropDownId.replace("type-", "");
  currentType = id;
  $("#current-type").text(id);
});

function findBySearch(value) {
  if (value.length > 0) {
    localStorage.setItem("SEARCH", value);
    searchEntityByName(value);
  }
  // else if (value.length == 0) {
  //   // location.reload();
  //   $("#data-table").load("index.html #data-table");
  // }
}

function fillDataTable(dataset) {
  // $("#data-table").load("index.html #data-table");
  // $("#data-table tbody").remove();
  // let dataset = localStorage.getItem("DATA");
  // if (dataset === undefined || dataset === null) {
  //   return;
  // }

  // dataset = JSON.parse(dataset);
  $("#data-table").treeTable({
    data: dataset,
    columns: [
      {
        data: "name",
      },
      {
        data: "revision",
      },
      {
        data: "type",
      },
      {
        data: "policyRef",
      },
      {
        data: "relDefRef",
      },
      {
        data: "kind",
      },
      {
        data: "vaultRef",
      },
      {
        data: "id",
        render: function (data) {
          var filename = "";
          for (let e of dataset) {
            if (e.id == data) {
              filename = data; // .replaceAll(".", "+");
              // +
              // "-" +
              // e.type +
              // "_" +
              // e.name +
              // "_" +
              // e.revision
              break;
            }
          }
          const button =
            "<button title='Export' class='btn btn-secondary' id='actiondownl-" +
            filename +
            "'><span class='glyphicon glyphicon-download' aria-hidden='true'></span></button>";

          return data.includes(".") ? button : null;
        },
      },
    ],
  });
}

$(document).ready(function () {
  // fillDataTable();

  // $("#data-table_length select").empty();

  $("#data-table_length select").append(
    "<option value='1000000000'>all</option>"
  );
  const value = localStorage.getItem("SEARCH");
  $("#search").val(value);
  $("#search").focus();
  $("#search").on("input", function () {
    tracker = {};
    var typedValue = $(this).val();
    findBySearch(typedValue);
  });

  $("#search-button").click(function () {
    var typedValue = $("#search").val();
    findBySearch(typedValue);
  });

  $("#export-button").click(function () {
    $("#data-table").table2excel({
      name: "Sheet",
      filename: "export-at-" + new Date().getTime() + ".xls",
    });
  });

  $("#file-button").click(function () {
    var url =
      SERVER + "entities/export?ids=" + removeDuplicates(entities).join(";");
    window.open(url);
    alert("Files downloaded !");
  });

  $(document).on("click", 'button[id^="actiondel-"]', function () {
    $(this)
      .parent()
      .parent()
      .fadeTo(400, 0, function () {
        $(this).remove();
      });
  });

  $(document).on("click", 'button[id^="actiondownl-"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var entityId = parts[1]; //.replaceAll("+", ".");
    // var filename = parts[2];
    console.log("Base entity : ", id);
    // console.log("Filename :", filename);
    var url = SERVER + "entities/export?ids=" + entityId;
    window.open(url);
    alert("Files downloaded !");
  });
});
