var contentId = "data-table-body";
var parentContentId = "data-table-parent-body";
var fileContentId = "data-table-file-body";
function depth_structure(entity, data) {
  let _data = JSON.parse(JSON.stringify(data));
  if (!("children" in entity)) {
    entity.children = [];
  }
  for (var i = 0; i < _data.length; i++) {
    if (
      _data[i].parentEntityId === entity.id &&
      entity.level + 1 == _data[i].level
    ) {
      if (entity.show_c === false) {
        _data[i].show_p = entity.show_h;
        _data[i].show_h = true;
        _data[i].show_c = false;
      }

      if (entity.show_c === true) {
        _data[i].show_p = entity.show_h;
        _data[i].show_h = true;
        _data[i].show_c = true;
      }
      
      entity.children.push(depth_structure(_data[i], _data));
    }
  }
  return entity;
}

function extractRoot(data) {
  var output = [];
  for (var i = 0; i < data.length; i++) {
    if (data[i].level === 0) {
      data[i].show_p = true;
      data[i].show_h = true;
      data[i].show_c = false;
      output.push(depth_structure(data[i], data));
    }
  }
  // alert(output.length);
  return output;
}

function count_space(level) {
  var output = "";
  for (var i = 0; i < 5 * level; i++) {
    output += "\t";
  }
  return output;
}

function truncate(value, limit) {
  if (value == null) {
    return "Empty";
  }
  if (value.length <= limit) {
    return value;
  }
  return value.slice(0, limit)+"...";
}


function return_file_table_row(file) {
  
  const fileButton = `<i class="bi bi-cloud-download squared margin-right-5" id="down-expand-${file?.id}"></i>`;
  const out = `<tr id="${file.busId}">
            <td> ${file?.type} </td>          
            <td>${file?.name}</td> 
            <td>${file?.revision}</td>
            <td>${file?.format}</td>
            <td> ${file?.localLocationCleaned + ""} </td>
            <td> ${file?.filename + ""} </td>
            <td> ${file?.filesize + ""} </td>
            <td> ${fileButton}</td>
        </tr>`;
  return out;
  // return entity?.show_h === true ? out : "";
}


/*
  // <td> ${entity?.kind + ""} </td>
*/
function return_table_row(parent, entity, id) {
  if (id != null && entity.id === id) {
    entity.show_h = !entity.show_h;
    for (var i = 0; i < entity.children.length; i++) {
      entity.children[i].show_h = entity.show_c;
      entity.children[i].show_c = false;
      entity.children[i].show_p = entity.show_h;
    }
  }

  if (entity.id !== id && parent?.show_c === false && entity.level > 0) {
    return "";
  }
  var filename = entity.id;
  const expAllButton = `<i class="squared margin-right-10" id="a-expand-${entity?.id}" title="expand all">e</i>`;
  const parentButton = `<i class="squared margin-right-5" id="p-expand-${entity?.id}" title="show parents">p</i>`;
  const attributeButton = `<i class="squared margin-right-5" id="attr-expand-${entity?.id}" title="show attributes">a</i>`;
  const fileButton = `<i class="squared margin-right-5" id="f-expand-${entity?.id}">Files</i>`;
  const button =
    `<button title='Export' class='btn btn-secondary action-style' id='actiondownl-${filename}'><i class='bi bi-cloud-download'></i></button> ${expAllButton} ${parentButton} ${attributeButton}`;
  const expandButton = `<i class="bi bi-caret-right-fill squared margin-right-5" id="i-expand-${entity?.id}">+</i>`;
  const collapseButton = `<i class="bi bi-caret-down-fill squared margin-right-5" id="i-collapse-${entity?.id}">-</i>`;
  const out = `<tr id="${entity.id}">
            <td> ${button} </td>          
            <td style="padding-left: ${(3 + entity?.level) * 10}px; padding-top: 10px;" title="${entity?.name}"> ${
    entity?.show_h === true && !entity?.show_c ? expandButton : collapseButton
  } ${ truncate(entity?.name, 50) + ""} (${entity?.children.length})</td>
            <td>N</td> 
            <td>N</td>
            <td>N</td>
            <td> ${entity?.type + ""} </td>
            <td> ${entity?.revision + ""} </td>
            <td title="${entity?.description}"> ${ truncate(entity?.description, 15) + ""} </td>
            <td> ${entity?.stateName + ""} </td>
            <td> ${entity?.policyRef + ""} </td>
            <td> ${entity?.relDefRef + ""}</td>
            <td> ${fileButton}</td>
        </tr>`;
  return (parent?.show_c === true)  || (parent == null && entity?.level === 0) ? out : "";
  // return entity?.show_h === true ? out : "";
}

function showEntityRow(parent, entity, id) {
  var out = return_table_row(parent, entity, id);
  if (out != "") {
    $("#" + contentId).append(out);
  }
  
  for (var i = 0; i < entity.children.length; i++) {
    showEntityRow(entity, entity.children[i], id);
  }
}

function showDataTable(data, id) {
  var tree = null;
  console.log("Data : ", data);
  if (data != null && data.length > 0 && data[0].children) {
    tree = data;
    console.log('good side');
  } else {
    tree = extractRoot(data);
    console.log('bad side');
  }
  console.log("My Tree : ", tree);

  for (var i = 0; i < tree.length; i++) {
    showEntityRow(null, tree[i], id);
  }
  return tree;
}

function hide_children(id, entity, state_h, state_c) {
  for(var i = 0; i < entity.children.length; i++) {
      entity.children[i].show_p = state_h;
      entity.children[i].show_h = state_c;
      entity.children[i].show_c = false;
      entity.children[i].children = hide_children(id, entity.children[i], state_h, false);
  }
  return entity.children;
}

function show_children(id, entity, state_h, state_c) {
  for(var i = 0; i < entity.children.length; i++) {
      entity.children[i].show_p = state_h;
      entity.children[i].show_h = state_c;
      entity.children[i].show_c = true;
      entity.children[i].children = show_children(id, entity.children[i], state_h, true);
  }
  return entity.children;
}

function deepUpdate(entity, id, status) {
  if (entity.id === id) {
    console.log('Entity : ', entity);
    console.log(entity.show_h, entity.show_c, id, status);
    if (status === "expand") {
      entity.show_h = true;
      entity.show_c = !entity.show_c;
      entity.children = hide_children(id, entity, entity.show_h, entity.show_c);
    } else if (status === "collapse") {
      entity.show_h = true;
      entity.show_c = !entity.show_c;
      entity.children = hide_children(id, entity, entity.show_h, entity.show_c);
    }
    console.log('last values : ', entity.show_h, entity.show_c);
    console.log('Entity after : ', entity);
  }
  for(var i = 0; i < entity.children.length; i++) {
    entity.children[i] = deepUpdate(entity.children[i], id, status);
  }
  return entity;
}

function deepUpdates(entity, id, status) {
  if (entity.id === id) {
    console.log('Entity : ', entity);
    console.log(entity.show_h, entity.show_c, id, status);
    if (status === "expand-a") {
      entity.show_h = true;
      entity.show_c = !entity.show_c;
      entity.children = show_children(id, entity, entity.show_h, entity.show_c);
    } else if (status === "collapse-a") {
      entity.show_h = true;
      entity.show_c = !entity.show_c;
      entity.children = show_children(id, entity, entity.show_h, entity.show_c);
    }
    console.log('last values : ', entity.show_h, entity.show_c);
    console.log('Entity after : ', entity);
  }
  for(var i = 0; i < entity.children.length; i++) {
    entity.children[i] = deepUpdates(entity.children[i], id, status);
  }
  return entity;
}

function updateVisibility(status, id, data) {
  $("#" + contentId).empty();
  console.log('Before', data);
  console.log(id);
  let result = [];
  for (var i = 0; i < data.length; i++) {
    result.push(deepUpdate(data[i], id, status));
  }
  console.log('After', result);
  showDataTable(result, id);
  return result;
}

function return_parent_table_row(entity) {

  const out = `<tr id="${entity.id}">
            <td style="padding-left: ${(3*entity?.level + 2) * 10}px; cursor: pointer; padding-top: 10px;" title="${entity?.name}" onclick="loadFromChild('${entity?.id}')"> ${ truncate(entity?.name, 100) + ""}</td>
            <td>N</td> 
            <td>N</td>
            <td>N</td>
            <td> ${entity?.type + ""} </td>
            <td> ${entity?.revision + ""} </td>
            <td title="${entity?.description}"> ${entity?.description + ""} </td>
            <td> ${entity?.stateName + ""} </td>
            <td> ${entity?.policyRef + ""} </td>
            <td> ${entity?.relDefRef + ""}</td>
            <td> ${entity?.vaultRef + ""}</td>
        </tr>`;
  return out;
}

function updateChildrenVisibility(status, id, data) {
  $("#" + contentId).empty();
  let result = [];
  for (var i = 0; i < data.length; i++) {
    result.push(deepUpdates(data[i], id, status));
  }
  console.log('After', result);
  showDataTable(result, id);
  return result;
}