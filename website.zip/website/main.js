const host = window.location.hostname ? window.location.hostname : "localhost";
const SERVER = `http://${host}:8009/api/`;

// alert(SERVER);

let currentType = "Projekt";
// let currentType = "Projektstufe";
// let currentType = "CATProduct";
let tracker = {};
let entities = [];
let oldTextLength = 0;

let datasets = [];

function makeRequest(url, success) {
  if (!url in tracker) {
    tracker[url] = 0;
  }

  if (tracker[url] == 1 && !url.includes("search-by")) {
    return;
  }

  $.ajax({
    url: url,
    type: "GET",
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Authorization": localStorage.getItem('TOKEN')
    },
    success: function (data) {
      success(data);
    },
    error: function (error) {
      console.error("Request error : " + error.statusText);
    },
  });
}

function makeGetRequest(url, success, failure) {
  $.ajax({
    url: url,
    type: "GET",
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Authorization": localStorage.getItem("TOKEN")
    },
    success: function (data) {
      success(data);
    },
    error: function (error) {
      console.error("Request error : " + error.statusText);
      failure(error);
    },
  });
}

function makePostRequest(url, data, success, failure) {
  $.ajax({
      url: url,
      type: "POST",
      data: JSON.stringify(data),
      dataType: "json",
      contentType: "application/json",
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Authorization": localStorage.getItem("TOKEN")
      },
      success: function (_data) {
        success(_data);
      },
      error: function (error) {
          console.error("Request error : " + error.statusText);
          failure(error);
      },
    });
}


function searchEntityByName(value) {
  var url =
    SERVER +
    "entities/search-by?type=" +
    currentType +
    "&value={value}".replace("{value}", value);
    $('#loading-gif').show(1000);
  makeRequest(url, function (data) {
    $("#" + contentId).empty();
    datasets = [];
    if (data.length > 0) {
      $.each(data, function (index, item) {
        item.tt_key = item.id;
        item.tt_parent = item.parentEntityId ? item.parentEntityId : 0;
        if (!item.revision || item.revision == "None") item.revision = "-";
        if (!item.relDefRef) item.relDefRef = "";
        if (!item.kind) item.kind = "";
        if (!item.policyRef) item.policyRef = "";

        if (item.level == 0) {
          item.show_p = true;
          item.show_h = true;
          item.show_c = false;
        } else {
          item.show_p = false;
          item.show_h = false;
          item.show_c = false;
        }

        datasets.push(item);
        entities.push(item.id);
      });
    }
    console.log("Data obtained : ", datasets);
    $('#loading-gif').hide(3000);
    fillDataTable(datasets);
  });
}

/**
 * Actions space */

function removeFromSet(element, list) {
  output = [];
  for (const elt of list) {
    if (!(element == elt)) {
      output.push(elt);
    }
  }
  return output;
}

function removeDuplicates(arr) {
  let unique = arr.reduce(function (acc, curr) {
    if (!acc.includes(curr)) acc.push(curr);
    return acc;
  }, []);
  return unique;
}

$(document).on("click", 'a[id^="type-"]', function () {
  var dropDownId = $(this).attr("id");
  var id = dropDownId.replace("type-", "");
  currentType = id;
  $("#current-type").text(id);
});

function findBySearch(value) {
  if (value.length > 0) {
    localStorage.setItem("SEARCH", value);
    searchEntityByName(value);
  }
}

function fillDataTable(dataset) {
  out = showDataTable(dataset, null);
  datasets = out;
}

function checkLogin() {
  const token = localStorage.getItem("TOKEN");
  const CHECK_URL = SERVER + 'auth/check-auth?token=';
  var tmp = window.location.href;

  if (token !== 'none') {
    makeGetRequest(CHECK_URL + token, function (data) {
      if (data === "BAD") {
        if (tmp.includes("main") ) tmp = tmp.replace("main", "index");
        else if (tmp.includes("/?") ) tmp = tmp.replace("/?", "/index.html?");
        window.location.href = tmp;
      }
    }, function (error) {
        console.log(error);
    });
  } else {
    if (tmp.includes("main") ) tmp = tmp.replace("main", "index");
    else if (tmp.includes("/?") ) tmp = tmp.replace("/?", "/index.html?");
    window.location.href = tmp;
  }
}

function logout() {
  const token = localStorage.getItem("TOKEN");
  const LOGOUT_URL = SERVER + 'auth/logout?token=';
  var tmp = window.location.href;
  if (token !== 'none') {
    makePostRequest(LOGOUT_URL + token, {}, function (data) {
      console.log(data);
      if (data.ack === "DONE") {
        localStorage.setItem("TOKEN", "none");
        localStorage.setItem("REMEMBER_ME", "none");
        if (tmp.includes("main") ) tmp = tmp.replace("main.html", "");
        window.location.href = tmp;
      }

    }, function (error) {
        console.log(error);
    });
  }
}

function getParentEntities(childId='27212.3559.17465.52399') {
  const url = SERVER + `entities/${childId}/parents`;
  var output = [];
  $("#" + parentContentId).empty();
  makeGetRequest(url, function (data) {
    if (data.length > 0) {
      $.each(data, function (index, item) {
        if (!item.revision || item.revision == "None") item.revision = "-";
        if (!item.relDefRef) item.relDefRef = "";
        if (!item.policyRef) item.policyRef = "";
        if (!item.kind) item.kind = "";
        if(index == 0) item.level = 0;
        else item.level = 1;
        $("#" + parentContentId).append(return_parent_table_row(item));
        output.push(item);
      });
    }
    console.log("Data obtained : ", output);
    $('#div1-parent').fadeIn(); // Fades in the div
  }, function (error) {
      console.log(error);
  });
  return;
}

$(document).ready(function () {
  checkLogin();
  $('#loading-gif').hide();

  $('tbody').scroll(function(e) { 
    $('thead').css("left", -$("tbody").scrollLeft()); //fix the thead relative to the body scrolling
    $('thead th:nth-child(1)').css("left", $("tbody").scrollLeft()); //fix the first cell of the header
    $('tbody td:nth-child(1)').css("left", $("tbody").scrollLeft()); //fix the first column of tdbody
  });

  const value = localStorage.getItem("SEARCH");
  $("#search").val(value);
  $("#search").focus();
  $("#search").on("input", function () {
    tracker = {};
    var typedValue = $(this).val();
    findBySearch(typedValue);
  });

  $("#search-button").click(function () {
    var typedValue = $("#search").val();
    findBySearch(typedValue);
  });

  $("#exit-button").click(function () {
    logout();
  });

  $("#export-button").click(function () {
    $("#data-table").table2excel({
      name: "Sheet",
      filename: "export-at-" + new Date().getTime() + ".xls",
    });
  });

  $("#file-button").click(function () {
    var url =
      SERVER + "entities/export?ids=" + removeDuplicates(entities).join(";");
    window.open(url);
    alert("Files downloaded !");
  });

  $(document).on("click", 'button[id^="actiondel-"]', function () {
    $(this)
      .parent()
      .parent()
      .fadeTo(400, 0, function () {
        $(this).remove();
      });
  });

  $(document).on("click", 'button[id^="actiondownl-"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var entityId = parts[1];
    console.log("Base entity : ", id);
    var url = SERVER + "entities/export?ids=" + entityId;
    window.open(url);
    alert("Files downloaded !");
  });

  $(document).on("click", 'i[id^="i-"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var status = parts[1];
    var entityId = parts[2];
    var output = updateVisibility(status, entityId, datasets);
    datasets = output;
  });

  $(document).on("click", 'i[id^="a-"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var status = 'expand-a';
    var entityId = parts[2];
    var output = updateChildrenVisibility(status, entityId, datasets);
    datasets = output;
  });

  $(document).on("click", 'i[id^="p-"]', function () {
    var id = $(this).attr("id");
    var parts = id.split("-");
    var status = parts[1];
    var entityId = parts[2];
    getParentEntities(entityId);
  });

  $('#hide-parent-view').on("click", function () {
    $('#div1-parent').fadeOut(); // Fades out the div
  });
});
