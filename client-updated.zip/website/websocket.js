let ws, currentUser;
let traces = [];
let showIntervalTime = null;
let fetchIntervalTime = null;
let firstTime = true;

function connect() {

  ws = new WebSocket(`ws://${host}:8009/broadcast-tree`);

  ws.onmessage = function (e) {
    const data = JSON.parse(e.data);
    if (stillComputing) {
        if (data.state == "WIP") {
            $('#realtime-text').css('display', 'block');
            let information = data.content;
            const elements = information.split(';');
            traces.push(elements);
            if (firstTime) {
              $('#rt-total-processed-node').html(" " + elements[3]);
              $('#rt-actual-processed-node').html(" " + elements[0] + " " + elements[1] + " " + elements[2]);
              // $('#rt-estimated-total-nodes').html(" " + elements[4]);
              // $('#rt-estimated-running-time').html(" " + elements[4]*10e-4 + " seconds");
              firstTime = false;
            } 
        }
    } else {
        setTimeout(()=>{
          $('#realtime-text').css('display', 'none');
        }, 3000);
        firstTime = true;
        clearInterval(intervalTime);
        traces = [];
    }
    
  };  
}

function getData(entityId) {
  var token = localStorage.getItem("TOKEN");
  var url = SERVER + "entities/broadcast-tree?id={value}".replace("{value}", entityId) + "&session=" + token;
  makeRequest(url, function (data) {
    if (data.length > 0) {
      const elements = data.split(';');
      console.log(elements);
      traces.push(elements);
      if (firstTime) {
        $('#realtime-text').css('display', 'block');
        $('#rt-total-processed-node').html(" " + elements[3]);
        $('#rt-actual-processed-node').html(" " + elements[0] + " " + elements[1] + " " + elements[2]);
        // $('#rt-estimated-total-nodes').html(" " + elements[4]);
        // $('#rt-estimated-running-time').html(" " + elements[4]*10e-4 + " seconds");
        firstTime = false;
      } 
    }
  });
}

function getTreeFlux(entityId) {
  
  fetchIntervalTime = setInterval(() => {
    if (stillComputing) {
      getData(entityId);
    } else {
      if (traces.length > 0) {
        const elements = traces[traces.length - 1];
        $('#rt-total-processed-node').html(" " + elements[3]);
        $('#rt-actual-processed-node').html(" " + elements[0] + " " + elements[1] + " " + elements[2]);
        // $('#rt-estimated-total-nodes').html(" " + elements[4]);
        // $('#rt-estimated-running-time').html(" " + elements[4]*10e-4 + " seconds");
      }
      clearInterval(fetchIntervalTime);
      clearInterval(showIntervalTime);
      traces = [];
      firstTime = true;
    }
  }, 100);

  showIntervalTime = setInterval(() => {
    if (traces.length > 0) {
      const elements = traces[traces.length - 1];
      $('#rt-total-processed-node').html(" " + elements[3]);
      $('#rt-actual-processed-node').html(" " + elements[0] + " " + elements[1] + " " + elements[2]);
      // $('#rt-estimated-total-nodes').html(" " + elements[4]);
      // $('#rt-estimated-running-time').html(" " + elements[4]*10e-4 + " seconds");
    }
  }, 1000);
  
}


// connect();
// sendMessage();
