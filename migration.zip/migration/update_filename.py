import pandas as pd
from models.entity import Entity
from packages.migrator import Migrator
from tqdm import tqdm

migrator = Migrator()

data = pd.read_csv('./data/connection/filename.csv', sep=";", index_col=None)

for index, row in tqdm(data.iterrows()):
    entityId = row['busID']
    location = row['LocalLocationCleaned']
    print(entityId, location)
    result = Entity(migrator=migrator).update(
        field="path", value=location, id=entityId)
    print(f"Result status : {result}")
    # exit()
print('Done with success !')
