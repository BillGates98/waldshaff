import pandas as pd
from models.entity import Entity
from packages.migrator import Migrator
from tqdm import tqdm
from models.file import File


def split_arrays(a=[], n=1000):
    k, m = divmod(len(a), n)
    return (a[i*k+min(i, m):(i+1)*k+min(i+1, m)] for i in range(n))


def save_to_file(line, file_path):
    try:
        with open(file_path, 'a') as sql_file:
            sql_file.write(line + '\n')
    except IOError as e:
        print(f"An error occurred while writing to the file: {e}")


migrator = Migrator()

n = 2  # update if large file.

filename = 'filename'  # update by the root file name

data = pd.read_csv('./data/connection/' + filename +
                   '.csv', sep=";", index_col=None)

_data = split_arrays(a=data, n=n)

for _index, rows in enumerate(_data):
    output_file = './matrix/filenames/' + \
        filename + '_' + str(_index) + '_output.sql'
    for index, row in tqdm(rows.iterrows()):
        entityId = row['busID']
        location = row['LocalLocationCleaned']
        result = Entity(migrator=migrator).update(
            field="path", value=location, id=entityId)
        refile = File(data=row, migrator=migrator).save()
        # save_to_file(result, output_file)
    # print(f"Result status : {result}")
print('Done with success !')
