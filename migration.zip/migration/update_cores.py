import os

directory = "./matrix/"

for filename in os.listdir(directory):
    if "'" in filename:
        new_filename = filename.replace("'", "")

        old_file = os.path.join(directory, filename)
        new_file = os.path.join(directory, new_filename)

        os.rename(old_file, new_file)
        print(f"Renamed: {filename} -> {new_filename}")

print("All single quotes have been removed from filenames.")
