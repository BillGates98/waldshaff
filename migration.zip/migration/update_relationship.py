from models.entity import Entity
import pandas as pd
from models.relationship import RelationShip
from packages.migrator import Migrator
from tqdm import tqdm

migrator = Migrator()

# data = pd.read_csv('./data/connection/entity_relationship.csv', index_col=None)


# for index, row in tqdm(data.iterrows()):
#     entityId = row[0]
#     relationshipId = row[1]
#     # print(entityId, relationshipId)
#     result = RelationShip(migrator=migrator).update(
#         field="child_entity_id", value=entityId, id=relationshipId)
#     print(f"Result status : {result}")

# print('Done with success !')


migrator = Migrator()

simple_select = """ SELECT * FROM relationship """
main_query = """
    SELECT e.id, r.id
    FROM entity AS e, relationship AS r
    WHERE e.type = "{type}"
    AND e.name = "{name}"
    AND e.revision = "{revision}";
"""
data = migrator.fetch(simple_select)
for row in tqdm(data):
    type = row[1]
    name = row[2]
    revision = row[3]
    # print(type, name, revision)
    query = main_query.replace('{type}', type)
    query = query.replace('{name}', name)
    query = query.replace('{revision}', revision)
    _data = migrator.fetch(query)
    for _row in _data:
        parentEntityId = _row[0]
        childEntityId = _row[1]
        result = Entity(migrator=migrator).update(
            field="parent_entity_id", value=parentEntityId, id=childEntityId)
print('Done with success !')
