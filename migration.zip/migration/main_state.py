from models.attribute import Attribute

from models.state import State
from models.entity import Entity
from packages.migrator import Migrator
from packages.xmlparser import XMLParser
import shutil
import argparse
from log import save_logs_to_file


def move_proceed_file(input='', input_path='', output_path=''):
    # os.rename(input, input.replace('enqueue', 'proceed'))
    # os.replace(input, input.replace('enqueue', 'proceed'))
    shutil.move(input, input.replace(input_path, output_path))


def migrate(input_path='', output_path=''):
    migrator = Migrator()
    xmls_parseds = XMLParser(input_path=input_path).run()
    for bloc_xml in xmls_parseds:
        # parallelisme
        for file, bloc in bloc_xml:
            # save_logs_to_file('info', 'Running file : ' + str(file))
            if not 'businessObject' in bloc['ematrix']:
                continue
            data = bloc['ematrix']['businessObject']

            # 1. Business object
            entity_id = data['@id']

            #  2. State list {} : [{}]
            if 'stateList' in data:
                if int(data['stateList']['@count']) == 1:
                    data['stateList']['state'] = [
                        data['stateList']['state']]
                for v_state in data['stateList']['state']:
                    if 'current' in v_state and v_state['current'] == None:
                        v_state['entity_id'] = entity_id
                        v_state['xml_base_file'] = file.replace(input_path, '')
                        # state = State(data=v_state, migrator=migrator)
                        # state.save()
                        _data = {
                            'entityId': entity_id,
                            'state_name': v_state['name'],
                            'xml_base_file': v_state['xml_base_file'],
                            'owner': data['owner']['userRef'],
                            'creation_info': data['creationInfo']['datetime'],
                            'modification_info': data['modificationInfo']['datetime']
                        }
                        state = Entity(data={}, migrator=migrator)
                        state.update_many(data=_data, id=entity_id)
            # move file to proceed directory
            move_proceed_file(input=file, input_path=input_path,
                              output_path=output_path)


if __name__ == '__main__':

    def get_args():
        parser = argparse.ArgumentParser()
        parser.add_argument(
            '-i', '--input_path', default='./data/proceed/checkout_xml_1/', help='input path')
        parser.add_argument(
            '-o', '--output_path', default='./data/enqueue/checkout_xml_1/', help='output path')
        return parser.parse_args()

    args = get_args()
    migrate(input_path=args.input_path, output_path=args.output_path)
