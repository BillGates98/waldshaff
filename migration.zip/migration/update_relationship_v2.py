from models.entity import Entity
import pandas as pd
from models.relationship import RelationShip
from packages.migrator import Migrator
from tqdm import tqdm
import multiprocessing
import time

migrator = Migrator()

waiting_relationship_select = """ 
SELECT type, name, revision, count(*) as SM FROM `relationship` WHERE child_entity_id = 0 GROUP BY type, name, revision ORDER BY SM DESC
"""
data1 = migrator.fetch(waiting_relationship_select)


get_entity_id_select = """ SELECT id FROM entity WHERE type = "{type}" AND name = "{name}" AND revision = "{revision}";"""
main_Query = """UPDATE relationship SET child_entity_id = "{child_entity_id}" WHERE type = "{type}" AND name = "{name}" AND revision = "{revision}";"""


def query_builder(_query, type, name, revision, child_entity_id):
    # Prepare the query
    query = _query
    if child_entity_id:
        query = query.replace('{child_entity_id}', child_entity_id)
    if type:
        query = query.replace('{type}', type)
    if name:
        query = query.replace('{name}', name)
    if revision:
        query = query.replace('{revision}', revision)
    return query


def split_arrays(a=[], n=1000):
    k, m = divmod(len(a), n)
    return (a[i*k+min(i, m):(i+1)*k+min(i+1, m)] for i in range(n))


def save_to_file(line, file_path):
    try:
        with open(file_path, 'a') as sql_file:
            sql_file.write(line + '\n')
        # print(f"Successfully saved line to {file_path}")
    except IOError as e:
        print(f"An error occurred while writing to the file: {e}")


def process_row(rows):
    file_name = './matrix/import_relationship_' + \
        str(int(time.time())) + '.sql'
    save_to_file('\n', file_name)
    for row in rows:
        type = row[0]
        name = row[1]
        revision = row[2]
        # print(row)
        # exit()
        data = migrator.fetch(query_builder(
            get_entity_id_select, type, name, revision, None))
        for entity_id in data:
            id = entity_id[0]
            # Prepare the query
            output = query_builder(main_Query, type, name, revision, id)
            # Fetch data
            save_to_file(output, file_name)


# Define chunk size

__data = split_arrays(a=data1, n=10)
for rows in tqdm(__data):
    process_row(rows)


print('Done with success !')
