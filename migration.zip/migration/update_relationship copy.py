from models.entity import Entity
import pandas as pd
from models.relationship import RelationShip
from packages.migrator import Migrator
from tqdm import tqdm
import multiprocessing
import time

migrator = Migrator()

# data = pd.read_csv('./data/connection/entity_relationship.csv', index_col=None)


# for index, row in tqdm(data.iterrows()):
#     entityId = row[0]
#     relationshipId = row[1]
#     # print(entityId, relationshipId)
#     result = RelationShip(migrator=migrator).update(
#         field="child_entity_id", value=entityId, id=relationshipId)
#     print(f"Result status : {result}")

# print('Done with success !')


migrator = Migrator()

simple_select = """ SELECT type, name, revision FROM relationship """
main_query = """
    SELECT e.id as entity_id, r.id
    FROM entity AS e
    INNER JOIN relationship AS r
    WHERE e.type = "{type}"
    AND e.name = "{name}"
    AND e.revision = "{revision}";
"""
data = migrator.fetch(simple_select)


def split_arrays(a=[], n=1000):
    k, m = divmod(len(a), n)
    return (a[i*k+min(i, m):(i+1)*k+min(i+1, m)] for i in range(n))


def save_to_file(line, file_path):
    try:
        with open(file_path, 'a') as sql_file:
            sql_file.write(line + '\n')
        print(f"Successfully saved line to {file_path}")
    except IOError as e:
        print(f"An error occurred while writing to the file: {e}")


def process_row(rows):
    file_name = './matrix/import_' + str(int(time.time())) + '.sql'
    for row in rows:
        type = row[0]
        name = row[1]
        revision = row[2]
        # Prepare the query
        query = main_query.replace('{type}', type)
        query = query.replace('{name}', name)
        query = query.replace('{revision}', revision)
        # Fetch data
        print(query)
        _data = migrator.fetch(query)
        print(_data)
        if _data is not None:
            for _row in _data:
                entityId = _row[0]
                relationshipId = _row[1]
                out = RelationShip(migrator=migrator).update(
                    field="child_entity_id", value=entityId, id=relationshipId)
                save_to_file(out, file_name)


# Use ThreadPoolExecutor for parallel processing
# Define chunk size

# Create a pool of workers
with multiprocessing.Pool(10) as pool:
    __data = split_arrays(a=data, n=10)
    # Apply the process_row function to data in parallel with specified chunk size
    list(tqdm(pool.imap(process_row, __data)))


# sequential
# for row in tqdm(data):
#     type = row[1]
#     name = row[2]
#     revision = row[3]
#     # print(type, name, revision)
#     query = main_query.replace('{type}', type)
#     query = query.replace('{name}', name)
#     query = query.replace('{revision}', revision)
#     _data = migrator.fetch(query)
#     if _data != None:
#         for _row in _data:
#             entityId = _row[0]
#             relationshipId = _row[1]
#             result = RelationShip(migrator=migrator).update(
#                 field="child_entity_id", value=entityId, id=relationshipId)
print('Done with success !')
