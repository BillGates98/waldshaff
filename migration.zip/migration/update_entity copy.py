import pandas as pd
from models.entity import Entity
from packages.migrator import Migrator
from tqdm import tqdm

migrator = Migrator()

# data = pd.read_csv('./data/connection/entity_entity.csv', index_col=None)
simple_select = """ SELECT type, name, revision FROM relationship """
main_query = """
    SELECT r.parent_entity_id, r.child_entity_id
    FROM entity AS e, relationship AS r
    WHERE e.type = "{type}"
    AND e.name = "{name}"
    AND e.revision = "{revision}";
"""
data = migrator.fetch(simple_select)
for row in tqdm(data):
    type = row[1]
    name = row[2]
    revision = row[3]
    # print(type, name, revision)
    query = main_query.replace('{type}', type)
    query = query.replace('{name}', name)
    query = query.replace('{revision}', revision)
    _data = migrator.fetch(query)
    for _row in _data:
        parentEntityId = _row[0]
        childEntityId = _row[1]
        result = Entity(migrator=migrator).update(
            field="parent_entity_id", value=parentEntityId, id=childEntityId)
print('Done with success !')
