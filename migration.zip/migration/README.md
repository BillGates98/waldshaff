# 1. Migration of the xml files to the database

python3.8 ./main.python --input_path ./data/proceed/ --output_path ./data/enqueue/

# 2. Associate the entity parents with the entity children

## 2.1 run the command below in phpmyadmin and export the results to the csv file entitled as entity_entity.csv and save them in data/connection directory

SELECT r.parent_entity_id, r.child_entity_id
FROM entity AS e
INNER JOIN relationship AS r
ON e.type = r.type
AND e.name = r.name
AND e.revision = r.revision;

> add this line on the top of the file : parentId,childId

## 2.2 run the script 'update_entity.py'

python3.8 ./update_entity.py

# 3. Associate the relationship parents with the relationship children

## 3.1 run the command below and export the results to the csv file entitled as entity_relationship.csv and save them in data/connection directory

SELECT e.id, r.id
FROM entity AS e
INNER JOIN relationship AS r
ON e.type = r.type
AND e.name = r.name
AND e.revision = r.revision;

> add this line on the top of the file : entityId,relationshipId

## 3.2 run the script 'update_relationship.py'

python3.8 ./update_relationship.py


# 4. update the filename path of entity 

## 4.1 run the script 'update_filename.py'

python3.8 ./update_filename.py
