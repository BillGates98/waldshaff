package com.cenit.Waldaschaff.matrix.webservice.handlers;

import com.cenit.Waldaschaff.matrix.webservice.contrats.EntityContrat;
import com.cenit.Waldaschaff.matrix.webservice.entities.Entity;
import com.cenit.Waldaschaff.matrix.webservice.services.EntityService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.WebSocketMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


public class SocketConnexionHandler extends TextWebSocketHandler {

    List<WebSocketSession> webSocketSessions = Collections.synchronizedList(new ArrayList<>());

    // private final EntityService entityService;
    // @Autowired
    EntityService entityService;

    public SocketConnexionHandler(EntityService entityService) {
        this.entityService = entityService;
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws  Exception {
        super.afterConnectionEstablished(session);
        System.out.println(session.getId() + " Connected !");
        if (webSocketSessions.size() > 100) {
            session.close(CloseStatus.SERVICE_OVERLOAD);
        } else {
            webSocketSessions.add(session);
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        super.afterConnectionClosed(session, status);
        System.out.println(session.getId() + " DisConnected !");
        webSocketSessions.remove(session);
    }

    @Override
    public void handleMessage(WebSocketSession session, WebSocketMessage<?> message) throws Exception {
        // super.handleMessage(session, message);
        ArrayList<Entity> data = null;
        String content = (String) message.getPayload();
        ObjectMapper objectMapper = new ObjectMapper();
        EntityContrat entity = objectMapper.readValue(content, EntityContrat.class);
        System.out.println("Process received message : " + entity.getId() + " >> " + entity.getPfb() +  " >>> " + webSocketSessions.size());
        if (entity.getState().equalsIgnoreCase("START")) {
            this.entityService.findTreeEntityWSById(entity, session);
        }
        System.out.println("Process SWM ended ");
    }
}
