package com.cenit.Waldaschaff.matrix.webservice.services;

import com.cenit.Waldaschaff.matrix.webservice.entities.Entity;
import com.cenit.Waldaschaff.matrix.webservice.entities.File;

import java.util.ArrayList;
import java.util.List;


public interface FileService {
	
	public File findOneById(String id);

	public ArrayList<File> findByBusId(String busId);
}
