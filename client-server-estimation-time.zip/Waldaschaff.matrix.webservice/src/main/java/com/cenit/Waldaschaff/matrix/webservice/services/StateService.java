package com.cenit.Waldaschaff.matrix.webservice.services;

import com.cenit.Waldaschaff.matrix.webservice.entities.State;
import com.cenit.Waldaschaff.matrix.webservice.entities.User;

import java.util.ArrayList;


public interface StateService {
	
	public State findOneById(Long id);

	public ArrayList<State> findByEntityId(String entityId);
}
