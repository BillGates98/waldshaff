let ws, currentUser;
let traces = [];
let intervalTime = null;
let firstTime = true;

function connect() {

  ws = new WebSocket(`ws://${host}:8009/broadcast-tree`);

  ws.onmessage = function (e) {
    const data = JSON.parse(e.data);
    if (stillComputing) {
        if (data.state == "WIP") {
            $('#realtime-text').css('display', 'block');
            let information = data.content;
            const elements = information.split(';');
            traces.push(elements);
            if (firstTime) {
              $('#rt-total-processed-node').html(" " + elements[3]);
              $('#rt-actual-processed-node').html(" " + elements[0] + " " + elements[1] + " " + elements[2]);
              $('#rt-estimated-total-nodes').html(" " + elements[4]);
              $('#rt-estimated-running-time').html(" " + elements[4]*10e-4 + " seconds");
              firstTime = false;
            } 
        }
    } else {
        clearInterval(intervalTime);
        traces = [];
    }
    
  };  
}

function getTreeFlux(entityId) {
  $('#realtime-text').css('display', 'none');
  intervalTime = setInterval(() => {
    if (traces.length > 0) {
      const elements = traces[traces.length - 1];
      $('#rt-total-processed-node').html(" " + elements[3]);
      $('#rt-actual-processed-node').html(" " + elements[0] + " " + elements[1] + " " + elements[2]);
      $('#rt-estimated-total-nodes').html(" " + elements[4]);
      $('#rt-estimated-running-time').html(" " + elements[4]*10e-4 + " seconds");
    }
  }, 10);
  const payload = {id: entityId, state: 'START', content: '', pfb: PFB ? "pfb": ""};
  ws.send(JSON.stringify(payload));
}


// connect();
// sendMessage();
