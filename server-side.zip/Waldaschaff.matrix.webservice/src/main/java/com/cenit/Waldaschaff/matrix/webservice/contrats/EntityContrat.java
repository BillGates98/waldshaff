package com.cenit.Waldaschaff.matrix.webservice.contrats;

import lombok.Data;

@Data
public class EntityContrat {

    private String id;
    private String state;
    private String content;
    private String pfb;

    public EntityContrat() {}

    public EntityContrat(String id, String state, String content, String pfb) {
        this.id = id;
        this.state = state;
        this.content = content;
        this.pfb = pfb;
    }
}
