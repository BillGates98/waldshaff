package com.cenit.Waldaschaff.matrix.webservice.serviceImpls;

import com.cenit.Waldaschaff.matrix.webservice.TempDirectoryCreator;
import com.cenit.Waldaschaff.matrix.webservice.contrats.EntityContrat;
import com.cenit.Waldaschaff.matrix.webservice.entities.Relationship;
import com.cenit.Waldaschaff.matrix.webservice.repositories.RelationshipRepository;
import com.cenit.Waldaschaff.matrix.webservice.services.FileService;
import com.cenit.Waldaschaff.matrix.webservice.services.RelationshipService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cenit.Waldaschaff.matrix.webservice.entities.Entity;
import com.cenit.Waldaschaff.matrix.webservice.repositories.EntityRepository;
import com.cenit.Waldaschaff.matrix.webservice.services.EntityService;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketMessage;
import org.springframework.web.socket.WebSocketSession;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.lang.reflect.Array;
import java.nio.file.Path;
import java.util.*;

@Service
public class EntityServiceImpl implements EntityService {
	
	EntityRepository entityRepository;
	RelationshipService relationshipService;
	RelationshipRepository relationshipRepository;
	FileService fileService;

	@Value("${downloading.dataPath}")
	String parentPath;

	public EntityServiceImpl(EntityRepository entityRepository, RelationshipService relationshipService, FileService fileService, RelationshipRepository relationshipRepository) {
		super();
		this.entityRepository = entityRepository;
		this.relationshipService = relationshipService;
		this.relationshipRepository = relationshipRepository;
		this.fileService = fileService;
	}



	@Override
	public Entity findOneById(String id) {
		// TODO Auto-generated method stub
		return this.entityRepository.findOneById(id);
	}

	public ArrayList<String> findTypes() {
		return this.entityRepository.findTypes();
	}

	public List<Entity> findEntityByFilteringNames(String type, String name) {
        return this.entityRepository.findByTypeAndNameStartingWith(type, name);
	}

	@Override
	public void findTreeEntityWSById(EntityContrat contract, WebSocketSession output) throws IOException {
		this.findEntityWSTree(contract,  "simple", output);
	}

	@Override
	public List<Entity> findTreeEntityById(String id, boolean pfb) {
		ArrayList<Entity> entities = new ArrayList<>();
		ArrayList<Entity> _results = null;
		if (pfb) {
			_results = this.findEntityTree(id, "pfb", "simple");
		} else {
			_results = this.findEntityTree(id, "", "simple");
		}
		if (_results != null && !_results.isEmpty()) entities.addAll(_results);
		return entities;
	}

	@Override
	public List<Entity> findEntityByStartingWith(String type, String name, boolean wbom, int page, boolean pfb) {
		String[] acceptedTerms = {"kunde", "Fahrzeugtyp"}; // , "Eingangsauftrag kpl.", "Versanddokument"
		List<String> acceptedTypes = Arrays.asList(acceptedTerms);
		ArrayList<Entity> entities = new ArrayList<>(); //
        ArrayList<Entity> _entities = this.entityRepository.findByTypeAndNameStartingWith(type, name);
		ArrayList<Entity> tmp_entities = new ArrayList<>();
		if (!_entities.isEmpty() && pfb) {
			for(int i = 0; i < _entities.size(); i++) {
				Entity entity = _entities.get(i);
				if (entity.getType().equalsIgnoreCase("Produkt")) {
					if (entity.getStateName().equalsIgnoreCase("Freigabe zur Beschaffung")) tmp_entities.add(entity);
				} else {
					if (!entity.getType().equalsIgnoreCase("Produkt")) {
						tmp_entities.add(entity);
					}
				}
			}

			_entities = tmp_entities;
		}
		if (page > -1) {
			HashMap<String, Object> _pagedEntities = this.getCurrentPage(_entities, page);
			_entities = (ArrayList<Entity>) _pagedEntities.get("currentList");
		}
		/*
		    ArrayList<Entity> currentPage = this.getCurrentPage(page);
			Apply pagination
		*/
		if (wbom)  return _entities;
		/*String direction = "";
		if (acceptedTypes.contains(type)) {
			direction = "to";
		}*/
		if (_entities != null && !_entities.isEmpty()) {
			for(Entity entity: _entities) {
				// entity.setParentEntityId("");
				// entities.add(entity);
				ArrayList<Entity> _results = this.findEntityTree(entity.getId(), pfb ? "pfb": "", "simple");
				entities.addAll(_results);
			}
		}
		return entities;
	}

	@Override
	public List<Entity> findParentEntityByEntityId(String entityId) {
		ArrayList<Entity> entities = new ArrayList<>();
		Entity _entity = this.entityRepository.findOneById(entityId);
		String direction = "to";
		if (_entity != null) {
			// entity.setParentEntityId("");
			// entities.add(_entity);
			ArrayList<Entity> _results = this.findParentEntityTree(_entity.getId(), direction);
			entities.addAll(_results);
		}
		return entities;
	}

	public ArrayList<Entity> findParentEntityTree(String id, String source) {
		Entity entity = this.entityRepository.findOneById(id);
		ArrayList<Entity> data = new ArrayList<>();
		if (entity != null) {
			data.add(entity);
			List<Relationship> children = new ArrayList<>();
			List<Relationship> tmp = this.relationshipService.findByParentEntityId(entity.getId());
			// List<Relationship> tmp = this.relationshipService.findByParentEntityIdAndKind(entity.getId(), source);
			if (tmp != null) {
				for(Relationship relation : tmp) {
					relation.setLevel(entity.getLevel()+1);
					if (relation.getKind().equalsIgnoreCase("to")) children.add(relation);
				}
			}
			while(!children.isEmpty()) {
				Relationship relationship = children.remove(0);
				if (relationship.getChildEntityId() != null) {
					entity = this.entityRepository.findOneById(relationship.getChildEntityId());
					if (entity != null && !data.contains(entity)) {
						entity.setLevel(relationship.getLevel());
						entity.setRelDefRef(relationship.getRelDefRef());
						entity.setParentEntityId(relationship.getParentEntityId());
						data.add(entity);
					}
				}
			}
		}
		return data;
	}

	@Override
	public ArrayList<String> getEntityFilenames(String entityId) {
		ArrayList<String> output = new ArrayList<>();
		Entity _entity = this.entityRepository.findOneById(entityId);
		if (_entity != null) {
			output.add(parentPath + "XML/" + _entity.getXmlBaseFile());
		}
		ArrayList<com.cenit.Waldaschaff.matrix.webservice.entities.File> _files = this.fileService.findByBusId(entityId);
		for(com.cenit.Waldaschaff.matrix.webservice.entities.File _file: _files) {
			String fullPath = parentPath + _file.getLocalLocationCleaned() + "/" + _file.getFilename();
			File file = new File(fullPath);
			if (file.exists()) {
				output.add(fullPath);
			}
		}
		return output;
	}

	private ArrayList<String> removePrefixFiles(ArrayList<String> files) {
		ArrayList<String> output = new ArrayList<>();

		HashMap<String, Long> counted = new HashMap<>();
		for (String file: files) {
			File _file = new File(file);
			if (!counted.containsKey(_file.getName())) {
				counted.put(_file.getName(), 1L);
			} else {
				Long value = counted.get(_file.getName()) + 1;
				counted.put(_file.getName(), value);
			}
		}

		for(String file: files) {
			if (!file.isEmpty()) {
				String[] value = file.split("/");
				String lastPart = value[value.length-1];
				File t_file = new File(file);
				if (this.acceptedExtensions(lastPart)) {
					if (!output.contains("CAD/" + lastPart)) output.add("CAD/" + lastPart);
					for (int i = 1; i < counted.get(t_file.getName()); i++) {
						if (!output.contains("CAD/" + i + "/" +  lastPart)) output.add("CAD/" + i + "/" +  lastPart);
					}
				} else {
					if (value.length > 2 && value[value.length-2].equalsIgnoreCase("XML")) {
						output.add("XML/" + lastPart);
					} else {
						output.add("non-CAD/" + lastPart);
					}
				}
			}
		}
		return output;
	}
	@Override
	public ArrayList<Entity> findEntityTree(String id, String pfb, String operation) {
		ArrayList<String> textEntities = new ArrayList<>();
		ArrayList<Entity> entities = new ArrayList<>();
		Entity entity = this.entityRepository.findOneById(id);
		ArrayList<Entity> data = new ArrayList<>();
		if (entity != null) {
			ArrayList<String> filenames = this.removePrefixFiles(this.getEntityFilenames(entity.getId()));
			if (!filenames.isEmpty()) entity.setFiles(filenames.toString());
			data.add(entity);
			textEntities.add(entity.lining());
			// entity.setCreationInfo("");
			entities.add(entity);
			List<Relationship> children = new ArrayList<>();
			// if (source.equalsIgnoreCase("to")) source = "from";
			List<Relationship> tmp = this.relationshipService.findByParentEntityId(entity.getId());
			System.out.println("Children: " + tmp.size() + " EntityId : " + entity.getId());
			// List<Relationship> tmp = this.relationshipService.findByParentEntityIdAndKind(entity.getId(), source);
            for (Relationship relation : tmp) {
				relation.setLevel(entity.getLevel() + 1);
				if (entity.getType().equalsIgnoreCase("Kunde")) {
					if (relation.getKind().equalsIgnoreCase("to")) children.add(relation);
				} else {
					if (relation.getKind().equalsIgnoreCase("from")) children.add(relation);
				}
            }
            while(!children.isEmpty()) {
				Relationship relationship = children.remove(0);
				// if (!relationship.getKind().equalsIgnoreCase("from")) continue;
				if (relationship.getChildEntityId() != null && relationship.getParentEntityId() != null) {
					entity = this.entityRepository.findOneById(relationship.getChildEntityId());
					if (pfb.equalsIgnoreCase("pfb")) {
						if (entity != null && entity.getType().equalsIgnoreCase("Produkt") && !entity.getStateName().equalsIgnoreCase("Freigabe zur Beschaffung")) {
							entity = null;
						}
					}
					if (entity != null && !data.contains(entity)) {//
						filenames = this.removePrefixFiles(this.getEntityFilenames(entity.getId()));
						if (!filenames.isEmpty()) entity.setFiles(filenames.toString()); // .replaceAll(parentPath, "")
						entity.setLevel(relationship.getLevel());
						entity.setRelDefRef(relationship.getRelDefRef());
						entity.setParentEntityId(relationship.getParentEntityId()); // ??????
						data.add(entity);
						textEntities.add(entity.lining());
						entities.add(entity);
						List<Relationship> sub_children = new ArrayList<>();
						// if (source.equalsIgnoreCase("to")) source = "from";
						tmp = this.relationshipService.findByParentEntityId(entity.getId());
						// System.out.println("Children >>: " + entity.getId() + " child-count >># " + tmp.size() + " remaining >># " + children.size());
						// tmp = this.relationshipService.findByParentEntityIdAndKind(entity.getId(), source);
                        for (Relationship relation : tmp) {
							if (relation.getKind().equalsIgnoreCase("from")) {
								relation.setLevel(entity.getLevel() + 1);
								// Entity _entity = this.entityRepository.findOneById(relation.getChildEntityId());
								sub_children.add(relation);
							}
							/*else {
								Entity _entity = this.entityRepository.findOneById(relationship.getChildEntityId());
								entities.add(_entity);
							}*/
                        }
                        if (!sub_children.isEmpty()) {
							children.addAll(sub_children);
						}
					}
				}

			}
		}
		System.out.println(data.size() + " >>>>>>>>>>>>>>>>>><<");
		ArrayList<String> xmlFormatEntities = new ArrayList<>();
		xmlFormatEntities.add("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		int oldLevel = -1;
		int elementCount = 1;
		for(Entity entityX: entities) {

			if (entityX.getLevel() - oldLevel == 1) {
				xmlFormatEntities.add(entityX.tagging());
			} else {
				if (entityX.getLevel() - oldLevel == 0) {
					xmlFormatEntities.add(entityX.tagging());
					xmlFormatEntities.add("</Entity>");
					elementCount++;
				}
				if (entityX.getLevel() - oldLevel < 0) {
					xmlFormatEntities.add("</Entity>");
					xmlFormatEntities.add(entityX.tagging());
					xmlFormatEntities.add("</Entity>");
					elementCount +=2;
				}
			}
			oldLevel = entityX.getLevel();
		}
		for(int i=0; i < entities.size() - elementCount + 1; i++) {
			xmlFormatEntities.add("</Entity>");
		}
		// System.out.println("Go : " + entities.size() + " >> " + elementCount);
		if (operation.equalsIgnoreCase("export")) {
			writeTreeToFile(textEntities, entities.get(0), "CSV.csv");
			writeTreeToFile(xmlFormatEntities, entities.get(0), "Xml.xml");
		}
		return data;
	}

	@Override
	public HashMap<String, String> findRelationDefinitions(String entityId) {
		HashMap<String, String> output = new HashMap<>();
		output.put("RefE", "0");
		output.put("RefV", "0");
		output.put("RefF", "0");
		HashMap<String, String> toCheck = new HashMap<>();
		toCheck.put("Eingangsauftrag kpl.", "RefE");
		toCheck.put("Fahrzeugtyp", "RefF");
		toCheck.put("Versanddokument", "RefV");
		ArrayList<Relationship> relations = (ArrayList<Relationship>) this.relationshipService.findByParentEntityId(entityId);

		if (!relations.isEmpty()) {
			for(Relationship relation: relations) {
				if (toCheck.containsKey(relation.getRelDefRef())) {
					output.put(toCheck.get(relation.getRelDefRef()), "1");
				}
			}
		}
		return output;
	}


	public void writeTreeToFile(ArrayList<String> textEntities, Entity entity, String fileType) {
		StringBuilder output = new StringBuilder();
		output.append("Name;type;Revision;StateName;Id;PolicyRef;RelDefRef;Path;Files\n");
		for(int i = 0; i < textEntities.size(); i++) {
			output.append(textEntities.get(i));
		}
		// build parent path
		if (!textEntities.isEmpty()) {
			String pathName =  entity.getType() + "_" + entity.getName() + "_" + entity.getRevision();
			Path parentPath = new TempDirectoryCreator(pathName).getTmpDirectory();
			System.out.println("Base Name : " + pathName + " >> " + parentPath.toAbsolutePath().toString());
			pathName = parentPath.toAbsolutePath().toString();
			writeToFile(output.toString(), pathName, fileType);
		}
	}

	public void writeToFile(String stringToWrite, String directoryPath, String fileType) {
		try {
			File file = new File(directoryPath, "tree"+ fileType);
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			writer.write(stringToWrite);
			writer.close();
			System.out.println("String written to file: " + file.getAbsolutePath());
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private boolean acceptedExtensions(String file) {
		ArrayList<String> extensions = new ArrayList<>();
		extensions.add("CATProduct");
		extensions.add("CATPart");
		extensions.add("CATDrawing");
		extensions.add("model");
		for (String ext: extensions) {
			if (file.endsWith("." + ext)) return true;
		}
		return false;
	}

	private HashMap<String, Object> getCurrentPage(ArrayList<Entity> entities, int page) {
		int limit = 15;
		ArrayList<ArrayList<Entity>> subLists = new ArrayList<>();
		int totalSize = entities.size();
		for (int i = 0; i < totalSize; i += limit) {
			int end = Math.min(i + limit, totalSize);
			subLists.add(new ArrayList<>(entities.subList(i, end)));
		}
		HashMap<String, Object> output = new HashMap<>();
		output.put("currentList", null);
		int totalPages = subLists.size();
		if (page < totalPages) {
			output.put("currentList", subLists.get(page));
		}
		return output;
	}



	/*         -----------------------------------------------      */
	public void sendRealTimeFlux(EntityContrat contract, Object data, WebSocketSession output) throws IOException {
		if (data.getClass() == String.class) {
			ObjectMapper objectMapper = new ObjectMapper();
			contract.setState("WIP");
			contract.setContent(data+"");
			String jsonString = objectMapper.writeValueAsString(contract);
			TextMessage message = new TextMessage(jsonString);
			output.sendMessage(message);
		} else if (data.getClass() == ArrayList.class) {
			ObjectMapper objectMapper = new ObjectMapper();
			String jsonString = objectMapper.writeValueAsString(data);
			contract.setState("DONE");
			contract.setContent(jsonString);
			jsonString = objectMapper.writeValueAsString(contract);
			TextMessage message = new TextMessage(jsonString);
			output.sendMessage(message);
		}
	}

	public void findEntityWSTree(EntityContrat contract, String operation, WebSocketSession output) throws IOException {
		ArrayList<String> textEntities = new ArrayList<>();
		String message = "";
		ArrayList<Entity> entities = new ArrayList<>();
		Entity entity = this.entityRepository.findOneById(contract.getId());
		ArrayList<Entity> data = new ArrayList<>();
		if (entity != null) {
			ArrayList<String> filenames = this.removePrefixFiles(this.getEntityFilenames(entity.getId()));
			if (!filenames.isEmpty()) entity.setFiles(filenames.toString());
			data.add(entity);
			textEntities.add(entity.lining());
			// entity.setCreationInfo("");
			entities.add(entity);
			List<Relationship> children = new ArrayList<>();
			// if (source.equalsIgnoreCase("to")) source = "from";
			List<Relationship> tmp = this.relationshipRepository.findByParentEntityId(entity.getId());
			System.out.println("Children: " + tmp.size() + " EntityId : " + entity.getId());
			// List<Relationship> tmp = this.relationshipService.findByParentEntityIdAndKind(entity.getId(), source);
			for (Relationship relation : tmp) {
				relation.setLevel(entity.getLevel() + 1);
				if (entity.getType().equalsIgnoreCase("Kunde")) {
					if (relation.getKind().equalsIgnoreCase("to")) children.add(relation);
				} else {
					if (relation.getKind().equalsIgnoreCase("from")) children.add(relation);
				}
			}
			while(!children.isEmpty()) {
				Relationship relationship = children.remove(0);
				// if (!relationship.getKind().equalsIgnoreCase("from")) continue;
				if (relationship.getChildEntityId() != null && relationship.getParentEntityId() != null) {
					entity = this.entityRepository.findOneById(relationship.getChildEntityId());
					if (contract.getPfb().equalsIgnoreCase("pfb")) {
						if (entity != null && entity.getType().equalsIgnoreCase("Produkt") && !entity.getStateName().equalsIgnoreCase("Freigabe zur Beschaffung")) {
							entity = null;
						}
					}
					if (entity != null && !data.contains(entity)) {//
						filenames = this.removePrefixFiles(this.getEntityFilenames(entity.getId()));
						if (!filenames.isEmpty()) entity.setFiles(filenames.toString()); // .replaceAll(parentPath, "")
						entity.setLevel(relationship.getLevel());
						entity.setRelDefRef(relationship.getRelDefRef());
						entity.setParentEntityId(relationship.getParentEntityId()); // ??????
						data.add(entity);
						textEntities.add(entity.lining());
						entities.add(entity);
						List<Relationship> sub_children = new ArrayList<>();
						// if (source.equalsIgnoreCase("to")) source = "from";
						tmp = this.relationshipRepository.findByParentEntityId(entity.getId());
						message = "Children with Id#" + entity.getId() + " has " + tmp.size() + "children, so it remains " + (children.size()) + " elements to explore";
						// System.out.println(message);
						this.sendRealTimeFlux(contract,entity.getId() + ";" + tmp.size() + ";" + children.size(), output);
						// tmp = this.relationshipService.findByParentEntityIdAndKind(entity.getId(), source);
						for (Relationship relation : tmp) {
							if (relation.getKind().equalsIgnoreCase("from")) {
								relation.setLevel(entity.getLevel() + 1);
								// Entity _entity = this.entityRepository.findOneById(relation.getChildEntityId());
								sub_children.add(relation);
							}
							/*else {
								Entity _entity = this.entityRepository.findOneById(relationship.getChildEntityId());
								entities.add(_entity);
							}*/
						}
						if (!sub_children.isEmpty()) {
							children.addAll(sub_children);
						}
					}
				}
			}
		}
		System.out.println(data.size() + " >>>>>>>>>>>>>>>>>><<");
	}


}
