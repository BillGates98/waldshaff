package com.cenit.Waldaschaff.matrix.webservice.contrats;

import java.util.ArrayList;
import java.util.LinkedHashSet;

public class Util {

    public static <T> ArrayList<T> removeDuplicates(ArrayList<T> list) {
        // Use LinkedHashSet to maintain insertion order and remove duplicates
        LinkedHashSet<T> set = new LinkedHashSet<>(list);
        // Convert back to ArrayList
        return new ArrayList<>(set);
    }
}
