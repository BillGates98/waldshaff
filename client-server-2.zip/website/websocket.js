let ws, currentUser;

function connect() {

  ws = new WebSocket(`ws://${host}:8009/broadcast-tree`);

  ws.onmessage = function (e) {
    const data = JSON.parse(e.data);
    if (stillComputing) {
        if (data.state == "WIP") {
            $('#realtime-text').css('display', 'block');
            // console.log(data.content);
            let information = data.content;
            const elements = information.split(';');
            $('#rt-id').html(elements[0]);
            $('#rt-children-count').html(elements[1]);
            $('#rt-remaining-count').html(elements[2]);
        }
    } else {
        $('#realtime-text').css('display', 'none');
    }
    
  };  
}

function getTreeFlux(entityId) {
  const payload = {id: entityId, state: 'START', content: '', pfb: PFB ? "pfb": ""};
  ws.send(JSON.stringify(payload));
}


// connect();
// sendMessage();
