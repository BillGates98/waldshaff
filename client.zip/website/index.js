
const host = window.location.hostname ? window.location.hostname : "localhost";
const SERVER = `http://${host}:8009/api/`;

const LOGIN_URL = SERVER + 'auth/login';
const CHECK_URL = SERVER + 'auth/check-auth?token=';


function makeGetRequest(url, token, success, failure) {
  $.ajax({
    url: url,
    type: "GET",
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Authorization": token
    },
    success: function (data) {
      success(data);
    },
    error: function (error) {
      console.error("Request error : " + error.statusText);
      failure(error);
    },
  });
}

function makePostRequest(url, data, token, success, failure) {
    $.ajax({
        url: url,
        type: "POST",
        data: JSON.stringify(data),
        dataType: "json",
        contentType: "application/json",
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Authorization": token
        },
        success: function (_data) {
          success(_data);
        },
        error: function (error) {
            console.error("Request error : " + error.statusText);
            failure(error);
        },
      });
}

$(document).ready(function () {
    const token = localStorage.getItem("TOKEN");
    const rememberMe = localStorage.getItem("REMEMBER_ME");
    if (token !== null && rememberMe === "true") {
        makeGetRequest(CHECK_URL + token, token, function (data) {
            console.log(data);
            if (data === "GOOD") {
                var tmp = window.location.href;
                if (tmp.includes("index") ) tmp = tmp.replace("index", "main");
                else if (tmp.includes("/?") ) tmp = tmp.replace("/?", "/main.html?");
                window.location.href = tmp;
            }
        }, function (error) {
            console.log(error);
        });
    }

    $('#login-button').click(function () {
        var username = $('#floatingInput').val();
        var password = $('#floatingPassword').val();
        var rememberMe = $('#flexCheckDefault').is(':checked');

        if (username == "" || password == "") {
            alert('All the fields are required !')
            return;
        }
        makePostRequest(LOGIN_URL, {username: username, password: password, token : "LOGIN"}, 'LOGIN', function (data) {
            if (data.token !== "none") {
                localStorage.setItem("TOKEN", data.token);
                localStorage.setItem("REMEMBER_ME", rememberMe);
                var tmp = window.location.href; 
                if (tmp.includes("index") ) tmp = tmp.replace("index", "main");
                else if (tmp.includes("/?") ) tmp = tmp.replace("/?", "/main.html?");

                window.location.href = tmp;
            } else {
                alert('Wrong username or password !');
            }
        }, function (error) {
            console.log(error);
        });
    });

});
