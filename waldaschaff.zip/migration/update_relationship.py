import pandas as pd
from models.relationship import RelationShip
from packages.migrator import Migrator
from tqdm import tqdm

migrator = Migrator()

data = pd.read_csv('./data/connection/entity_relationship.csv', index_col=None)

for index, row in tqdm(data.iterrows()):
    entityId = row[0]
    relationshipId = row[1]
    # print(entityId, relationshipId)
    result = RelationShip(migrator=migrator).update(
        field="child_entity_id", value=entityId, id=relationshipId)
    print(f"Result status : {result}")

print('Done with success !')
