
const host = window.location.hostname ? window.location.hostname : "localhost";
const SERVER = `http://${host}:8009/api/`;

const LOGIN_URL = SERVER + 'auth/login';
const CHECK_URL = SERVER + 'auth/check-auth?token=';


function makeGetRequest(url, success, failure) {
  $.ajax({
    url: url,
    method: "GET",
    headers: {
      "Access-Control-Allow-Origin": "*",
    },
    success: function (data) {
      success(data);
    },
    error: function (error) {
      console.error("Request error : " + error.statusText);
      failure(error);
    },
  });
}

function makePostRequest(url, data, success, failure) {
    $.ajax({
        url: url,
        method: "POST",
        data: JSON.stringify(data),
        dataType: "json",
        contentType: "application/json",
        headers: {
          "Access-Control-Allow-Origin": "*"
        },
        success: function (_data) {
          success(_data);
        },
        error: function (error) {
            console.error("Request error : " + error.statusText);
            failure(error);
        },
      });
}

$(document).ready(function () {
    const token = localStorage.getItem("TOKEN");
    const rememberMe = localStorage.getItem("REMEMBER_ME");
    if (token !== null && rememberMe === "true") {
        makeGetRequest(CHECK_URL + token, function (data) {
            if (data === "GOOD") {
                var tmp = window.location.href.replace("index", "main");
                if (tmp.includes("?") === false) {
                    tmp += "?";
                }
                window.location.href = tmp + "token=" + token;
            }
        }, function (error) {
            console.log(error);
        });
    }

    $('#login-button').click(function () {
        var username = $('#floatingInput').val();
        var password = $('#floatingPassword').val();
        var rememberMe = $('#flexCheckDefault').is(':checked');

        if (username == "" || password == "") {
            alert('All the fields are required !')
            return;
        }
        makePostRequest(LOGIN_URL, {username: username, password: password, token : "none"}, function (data) {
            if (data.token !== "none") {
                localStorage.setItem("TOKEN", data.token);
                localStorage.setItem("REMEMBER_ME", rememberMe);
                var tmp = window.location.href.replace("index", "main");
                if (tmp.includes("?") === false) {
                    tmp += "?";
                }
                window.location.href = tmp + "token=" + data.token;
            } else {
                alert('Wrong username or password !');
            }
        }, function (error) {
            console.log(error);
        });
    });

});
