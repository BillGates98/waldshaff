package com.cenit.Waldaschaff.matrix.webservice.entities;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@javax.persistence.Entity
@Table(name="user")
public class User {
	
	@Id
	@Column(name="id")
	private Long id;
	
	@Column(name="ref")
	private String ref;

	public User(Long id_,String ref_)
	{
		this.id = id_;
		this.ref = ref_;
	}
	
	public User() {
		super();
	}
	
}
