package com.cenit.Waldaschaff.matrix.webservice.controllers;

import com.cenit.Waldaschaff.matrix.webservice.entities.Auth;
import com.cenit.Waldaschaff.matrix.webservice.entities.User;
import com.cenit.Waldaschaff.matrix.webservice.services.AuthService;
import com.cenit.Waldaschaff.matrix.webservice.services.UserService;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping(value="/api/auth")
@CrossOrigin(value = "*")
public class AuthController {

	AuthService authService;

	public AuthController(AuthService authService) {
		this.authService = authService;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	HttpEntity<Auth> login(@RequestBody Auth contract) {

	   Auth user = this.authService.findOneByUsernameAndPassword(contract.getUsername(), contract.getPassword());
	   if(user != null) {
		   user = this.authService.login(user);
		   user.setUsername("@@@@@@@@@");
		   user.setPassword("@@@@@@@@@");
	   } else {
		   user = contract;
	   }
	   return new ResponseEntity<>(user, HttpStatus.OK);
	}

	@RequestMapping(value = "/check-auth", method = RequestMethod.GET)
	HttpEntity<String> checking(@RequestParam("token") String token) {
		Auth user = this.authService.findOneByToken(token);
		if(user != null) {
			return new ResponseEntity<>("GOOD", HttpStatus.OK);
		}
		return new ResponseEntity<>("BAD", HttpStatus.NOT_FOUND);
	}

	@RequestMapping(value = "/logout", method = RequestMethod.POST)
	HttpEntity<String> logout(@RequestParam("token") String token) {
		String ack = this.authService.logout(token);
		return new ResponseEntity<>(ack, HttpStatus.OK);
	}

}
