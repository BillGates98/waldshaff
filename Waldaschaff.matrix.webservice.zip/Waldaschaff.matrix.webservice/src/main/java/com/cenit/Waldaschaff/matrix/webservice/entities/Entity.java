package com.cenit.Waldaschaff.matrix.webservice.entities;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Data;

@Data
@javax.persistence.Entity
@Table(name="entity")
public class Entity {
	
	@Id
	@Column(name="id")
	private String id;
	
	@Column(name="type")
	private String type;
	
	@Column(name="name")
	private String name;
	
	@Column(name="revision")
	private String revision;
	
	@Column(name="description")
	private String description;
	
	@Column(name="policy_ref")
	private String policyRef;
	
	@Column(name="owner")
	private String owner;
	
	@Column(name="creation_info")
	private String creationInfo;
	
	@Column(name="modification_info")
	private String modificationInfo;
	
	@Column(name="current_state")
	private String currentState;
	
	@Column(name="vault_ref")
	private String vaultRef;

	@Column(name="path")
	private String path;

	@Column(name="format")
	private String format;

	@Column(name="filename")
	private String filename;

	@Column(name="parent_entity_id")
	private String parentEntityId;

	@Transient
	private int level = 0;
	

	public Entity(String id_,String type_,String name_,String revision_,String description_,String policyRef_,String owner_,String creationInfo_,String modificationInfo_,String currentState_,String vaultRef_, String path_, String format_, String filename_, String parent_entity_id_)
	{
		this.id = id_;
		this.type = type_;
		this.name = name_;
		this.revision = revision_;
		this.description = description_;
		this.policyRef = policyRef_;
		this.owner = owner_;
		this.creationInfo = creationInfo_;
		this.modificationInfo = modificationInfo_;
		this.currentState = currentState_;
		this.vaultRef = vaultRef_;
		this.path = path_;
		this.format = format_;
		this.filename = filename_;
		this.parentEntityId = parent_entity_id_;
	}
	
	public Entity() {
		super();
	}

	public String lining() {
		String tabulation = "\t";
		StringBuilder allTabs = new StringBuilder();
		for(int i = 0; i < this.level; i++) allTabs.append(tabulation);
		return allTabs.toString() + this.name + ";" + this.revision + ";" + this.type + ";" + this.id + "\n";
	}
	
}
