package com.cenit.Waldaschaff.matrix.webservice.services;

import com.cenit.Waldaschaff.matrix.webservice.entities.EntityAttribute;


public interface EntityAttributeService {
	
	public EntityAttribute findOneById(String id);
}
