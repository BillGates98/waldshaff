package com.cenit.Waldaschaff.matrix.webservice.serviceImpls;

import com.cenit.Waldaschaff.matrix.webservice.TempDirectoryCreator;
import com.cenit.Waldaschaff.matrix.webservice.entities.Relationship;
import com.cenit.Waldaschaff.matrix.webservice.services.FileService;
import com.cenit.Waldaschaff.matrix.webservice.services.RelationshipService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cenit.Waldaschaff.matrix.webservice.entities.Entity;
import com.cenit.Waldaschaff.matrix.webservice.repositories.EntityRepository;
import com.cenit.Waldaschaff.matrix.webservice.services.EntityService;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Service
public class EntityServiceImpl implements EntityService {
	
	EntityRepository entityRepository;
	RelationshipService relationshipService;
	FileService fileService;

	// @Value("${downloading.dataPath}")
	// String parentPath;

	public EntityServiceImpl(EntityRepository entityRepository, RelationshipService relationshipService, FileService fileService) {
		super();
		this.entityRepository = entityRepository;
		this.relationshipService = relationshipService;
		this.fileService = fileService;
	}


	@Override
	public Entity findOneById(String id) {
		// TODO Auto-generated method stub
		return this.entityRepository.findOneById(id);
	}

	@Override
	public List<Entity> findEntityByContaining(String type, String name) {
		ArrayList<Entity> entities = new ArrayList<>();
        ArrayList<Entity> _entities = this.entityRepository.findByTypeAndNameContaining(type, name);
		String direction = "from";
		if (type.equalsIgnoreCase("kunde")) {
			direction = "to";
		}
		if (_entities != null && !_entities.isEmpty()) {
			for(Entity entity: _entities) {
				// entity.setParentEntityId("");
				// entities.add(entity);
				ArrayList<Entity> _results = this.findEntityTree(entity.getId(), direction, "simple");
				entities.addAll(_results);
			}
		}
		return entities;
	}

	@Override
	public List<Entity> findParentEntityByEntityId(String entityId) {
		ArrayList<Entity> entities = new ArrayList<>();
		Entity _entity = this.entityRepository.findOneById(entityId);
		String direction = "to";
		if (_entity != null) {
			// entity.setParentEntityId("");
			// entities.add(_entity);
			ArrayList<Entity> _results = this.findEntityTree(_entity.getId(), direction, "simple");
			entities.addAll(_results);
		}
		return entities;
	}


	@Override
	public ArrayList<Entity> findEntityTree(String id, String source, String operation) {
		ArrayList<String> textEntities = new ArrayList<>();
		ArrayList<Entity> entities = new ArrayList<>();
		Entity entity = this.entityRepository.findOneById(id);
		ArrayList<Entity> data = new ArrayList<>();
		if (entity != null) {
			data.add(entity);
			textEntities.add(entity.lining());
			entity.setCreationInfo("");
			entities.add(entity);
			List<Relationship> children = new ArrayList<>();
			// if (source.equalsIgnoreCase("to")) source = "from";
			List<Relationship> tmp = this.relationshipService.findByParentEntityIdAndKind(entity.getId(), source);
			if (tmp != null) {
				for(Relationship relation : tmp) {
					relation.setLevel(entity.getLevel()+1);
					children.add(relation);
				}
			}
			while(!children.isEmpty()) {
				Relationship relationship = children.remove(0);
				if (relationship.getChildEntityId() != null) {
					entity = this.entityRepository.findOneById(relationship.getChildEntityId());
					if (entity != null && !data.contains(entity)) {
						entity.setLevel(relationship.getLevel());
						entity.setCreationInfo(relationship.getRelDefRef());
						entity.setParentEntityId(relationship.getParentEntityId());
						data.add(entity);
						textEntities.add(entity.lining());
						entities.add(entity);
						List<Relationship> sub_children = new ArrayList<>();
						if (source.equalsIgnoreCase("to")) source = "from";
						tmp = this.relationshipService.findByParentEntityIdAndKind(entity.getId(), source);
						if (tmp != null) {
							for(Relationship relation : tmp) {
								relation.setLevel(entity.getLevel()+1);
								sub_children.add(relation);
							}
						}

						if (!sub_children.isEmpty()) {
							sub_children.addAll(children);
							children = sub_children;
						}
					}
				}

			}
		}
		ArrayList<String> xmlFormatEntities = new ArrayList<>();
		xmlFormatEntities.add("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		int oldLevel = -1;
		int elementCount = 1;
		for(Entity entityX: entities) {

			if (entityX.getLevel() - oldLevel == 1) {
				xmlFormatEntities.add(entityX.tagging());
			} else {
				if (entityX.getLevel() - oldLevel == 0) {
					xmlFormatEntities.add(entityX.tagging());
					xmlFormatEntities.add("</Entity>");
					elementCount++;
				}
				if (entityX.getLevel() - oldLevel < 0) {
					xmlFormatEntities.add("</Entity>");
					xmlFormatEntities.add(entityX.tagging());
					xmlFormatEntities.add("</Entity>");
					elementCount +=2;
				}
			}
			oldLevel = entityX.getLevel();
		}
		for(int i=0; i < entities.size() - elementCount + 1; i++) {
			xmlFormatEntities.add("</Entity>");
		}
		System.out.println("Go : " + entities.size() + " >> " + elementCount);
		if (operation.equalsIgnoreCase("export")) {
			writeTreeToFile(textEntities, entities.get(0), "Text.txt");
			writeTreeToFile(xmlFormatEntities, entities.get(0), "Xml.xml");
		}
		return data;
	}


	public void writeTreeToFile(ArrayList<String> textEntities, Entity entity, String fileType) {
		StringBuilder output = new StringBuilder();
		for(int i = 0; i < textEntities.size(); i++) {
			output.append(textEntities.get(i));
		}
		// build parent path
		if (!textEntities.isEmpty()) {
			String pathName = entity.getName() + "_" + entity.getRevision() + "_" + entity.getType();
			Path parentPath = new TempDirectoryCreator(pathName).getTmpDirectory();
			System.out.println("Base Name : " + pathName + " >> " + parentPath.toAbsolutePath().toString());
			pathName = parentPath.toAbsolutePath().toString();
			writeToFile(output.toString(), pathName, fileType);
		}
	}

	public void writeToFile(String stringToWrite, String directoryPath, String fileType) {
		try {
			File file = new File(directoryPath, "tree"+ fileType);
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			writer.write(stringToWrite);
			writer.close();
			System.out.println("String written to file: " + file.getAbsolutePath());
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public String getFiles(String entityId) {
		StringBuilder output = new StringBuilder();
		ArrayList<com.cenit.Waldaschaff.matrix.webservice.entities.File> files = this.fileService.findByBusId(entityId);
		if (files != null) {
			for(com.cenit.Waldaschaff.matrix.webservice.entities.File file: files) {
				output.append(file.getLocalLocationCleaned() + "/" + file.getFilename());
			}
		}
		return output.toString();
	}


}
