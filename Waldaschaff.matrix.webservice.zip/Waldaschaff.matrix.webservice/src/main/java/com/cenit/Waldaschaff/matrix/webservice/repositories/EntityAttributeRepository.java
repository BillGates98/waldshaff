package com.cenit.Waldaschaff.matrix.webservice.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cenit.Waldaschaff.matrix.webservice.entities.EntityAttribute;

@Repository
public interface EntityAttributeRepository extends JpaRepository<EntityAttribute, Long> {
	
	public EntityAttribute findOneById(String id);
}
