package com.cenit.Waldaschaff.matrix.webservice.entities;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@javax.persistence.Entity
@Table(name="attribute")
public class Attribute {
	
	@Id
	@Column(name="id")
	private String id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="value_type")
	private String valueType;
	
	public Attribute(String Id_,String name_,String valueType_)
	{
		this.id = Id_;
		this.name = name_;
		this.valueType = valueType_;
	}
	
	public Attribute() {
		super();
	}
	
}
