package com.cenit.Waldaschaff.matrix.webservice.services;

import com.cenit.Waldaschaff.matrix.webservice.entities.Attribute;

public interface AttributeService {
	
	public Attribute findOneById(Long id);
}
