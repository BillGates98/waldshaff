package com.cenit.Waldaschaff.matrix.webservice.services;

import com.cenit.Waldaschaff.matrix.webservice.models.FileZipper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import javax.servlet.ServletOutputStream;
import java.io.*;
import java.util.ArrayList;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class FileZippingService {

    private static final String DOT = ".";
    private static final String ZIP = ".zip";

    private FileZippingService() {
    }

    static Logger logger = LoggerFactory.getLogger(FileZippingService.class);

    /**
     * Method to Zip a file
     *
     * @param fileZipper
     */
    public static void zipExportFile(ServletOutputStream streamOutput, ArrayList<String> files) {

        try {
            ZipOutputStream zipOut = new ZipOutputStream(streamOutput); // fos
            for (String sourceFileWithPath: files) {
                File fileToZip = new File(sourceFileWithPath);
                if (fileToZip.exists()) {
                    FileInputStream fis = new FileInputStream(fileToZip);
                    ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
                    zipOut.putNextEntry(zipEntry);
                    byte[] bytes = new byte[1024];
                    int length;
                    while ((length = fis.read(bytes)) >= 0) {
                        zipOut.write(bytes, 0, length);
                    }
                    fis.close();
                    logger.info("{} zipped successfully", sourceFileWithPath);
                    //if (fileZipper.isDeleteSourceAfterZipped()) deleteFile(sourceFileWithPath);
                }
            }
            zipOut.close();
            // fos.close();
        } catch (IOException e) {
            logger.error("Error while Zipping the file", e);
        }
    }

    public static void zipExportDirectory(String parentPath, ServletOutputStream streamOutput) throws IOException {
        String sourceFile = parentPath + "Compressed";
        ZipOutputStream zipOut = new ZipOutputStream(streamOutput);
        File fileToZip = new File(sourceFile);
        zipFile(fileToZip, fileToZip.getName(), zipOut);
        zipOut.close();
    }
    /**
     * Method to delete a file at given path
     *
     * @param fileToDelete
     */
    private static void deleteFile(String fileToDelete) {
        File filetoDelete = new File(fileToDelete);
        if (filetoDelete.exists()) {
            if (filetoDelete.delete()) {
                logger.info("{} deleted successfully.", fileToDelete);
            } else {
                logger.info("{} deletion unsuccessfull.", fileToDelete);
            }
        } else {
            logger.info("{} was not found for deletion.", fileToDelete);
        }

    }

    private static void zipFile(File fileToZip, String fileName, ZipOutputStream zipOut) throws IOException {
        if (fileToZip.isHidden()) {
            return;
        }
        if (fileToZip.isDirectory()) {
            if (fileName.endsWith("/")) {
                zipOut.putNextEntry(new ZipEntry(fileName));
                zipOut.closeEntry();
            } else {
                zipOut.putNextEntry(new ZipEntry(fileName + "/"));
                zipOut.closeEntry();
            }
            File[] children = fileToZip.listFiles();
            for (File childFile : children) {
                zipFile(childFile, fileName + "/" + childFile.getName(), zipOut);
            }
            return;
        }
        FileInputStream fis = new FileInputStream(fileToZip);
        ZipEntry zipEntry = new ZipEntry(fileName);
        zipOut.putNextEntry(zipEntry);
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
        fis.close();
    }


}