package com.cenit.Waldaschaff.matrix.webservice.controllers;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.cenit.Waldaschaff.matrix.webservice.entities.User;
import com.cenit.Waldaschaff.matrix.webservice.services.UserService;

@RestController
@RequestMapping(value="/users")
@CrossOrigin(origins = "*")
public class UserController {

	UserService userService;
	
	public UserController(UserService userService) {
		this.userService = userService;
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	HttpEntity<User> userRessource(@PathVariable("id") Long id) {
	   User entity = this.userService.findOneById(id);
	   return new ResponseEntity<>(entity, HttpStatus.OK);
	}
}
