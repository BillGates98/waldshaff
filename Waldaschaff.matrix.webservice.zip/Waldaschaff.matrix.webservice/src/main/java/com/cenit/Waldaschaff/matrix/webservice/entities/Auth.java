package com.cenit.Waldaschaff.matrix.webservice.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@javax.persistence.Entity
@Table(name="auth")
public class Auth {

	@Id
	@Column(name="id")
	private Long id;

	@Column(name="username", unique = true)
	private String username;

	@Column(name="password")
	private String password;

	@Column(name="token")
	private String token;

	public Auth(Long id_, String username, String password, String token)
	{
		this.id = id_;
		this.username = username;
		this.password = password;
		this.token = token;
	}

	public Auth() {
		super();
	}
	
}
