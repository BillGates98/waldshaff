package com.cenit.Waldaschaff.matrix.webservice.services;

import java.util.List;

import com.cenit.Waldaschaff.matrix.webservice.entities.Relationship;


public interface RelationshipService {
	
	public Relationship findOneById(String id);
	
	public List<Relationship> findByParentEntityId(String id);

	public List<Relationship> findByParentEntityIdAndKind(String id, String kind);

	public List<Relationship> findByChildEntityId(String id);
}
