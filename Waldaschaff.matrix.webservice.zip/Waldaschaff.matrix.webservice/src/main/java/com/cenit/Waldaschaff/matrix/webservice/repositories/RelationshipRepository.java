package com.cenit.Waldaschaff.matrix.webservice.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cenit.Waldaschaff.matrix.webservice.entities.Relationship;

@Repository
public interface RelationshipRepository extends JpaRepository<Relationship, Long> {
	
	public Relationship findOneById(String id);
	
	public List<Relationship> findByParentEntityId(String entityId);

	public List<Relationship> findByParentEntityIdAndKind(String entityId, String kind);

	public List<Relationship> findByChildEntityId(String entityId);
}
