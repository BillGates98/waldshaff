package com.cenit.Waldaschaff.matrix.webservice.entities;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@javax.persistence.Entity
@Table(name="entity_attribute")
public class EntityAttribute {
	
	@Id
	@Column(name="id")
	private String id;
	
	@Column(name="entity_type")
	private String entityType;
	
	@Column(name="entity_id")
	private String entityId;
	
	@Column(name="attribute_id")
	private String attributeId;
	
	@Column(name="value")
	private String value;
	

	public EntityAttribute(String Id_,String EntityType_,String EntityId_,String AttributeId_,String Value_)
	{
		this.id = Id_;
		this.entityType = EntityType_;
		this.entityId = EntityId_;
		this.attributeId = AttributeId_;
		this.value = Value_;
	}
	
	public EntityAttribute() {
		super();
	}

}
