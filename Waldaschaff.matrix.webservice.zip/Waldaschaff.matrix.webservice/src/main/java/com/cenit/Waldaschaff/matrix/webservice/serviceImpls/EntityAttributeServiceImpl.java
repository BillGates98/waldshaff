package com.cenit.Waldaschaff.matrix.webservice.serviceImpls;

import org.springframework.stereotype.Service;

import com.cenit.Waldaschaff.matrix.webservice.entities.EntityAttribute;
import com.cenit.Waldaschaff.matrix.webservice.repositories.EntityAttributeRepository;
import com.cenit.Waldaschaff.matrix.webservice.services.EntityAttributeService;

@Service
public class EntityAttributeServiceImpl implements EntityAttributeService {
	
	EntityAttributeRepository entityAttributeRepository;

	public EntityAttributeServiceImpl(EntityAttributeRepository entityAttributeRepository) {
		super();
		this.entityAttributeRepository = entityAttributeRepository;
	}


	@Override
	public EntityAttribute findOneById(String id) {
		// TODO Auto-generated method stub
		return this.entityAttributeRepository.findOneById(id);
	}

}
