package com.cenit.Waldaschaff.matrix.webservice.serviceImpls;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cenit.Waldaschaff.matrix.webservice.entities.Relationship;
import com.cenit.Waldaschaff.matrix.webservice.repositories.RelationshipRepository;
import com.cenit.Waldaschaff.matrix.webservice.services.RelationshipService;

@Service
public class RelationshipServiceImpl implements RelationshipService {
	
	RelationshipRepository relationshipRepository;

	public RelationshipServiceImpl(RelationshipRepository relationshipRepository) {
		super();
		this.relationshipRepository = relationshipRepository;
	}


	@Override
	public Relationship findOneById(String id) {
		// TODO Auto-generated method stub
		return this.relationshipRepository.findOneById(id);
	}


	@Override
	public List<Relationship> findByParentEntityId(String id) {
		// TODO Auto-generated method stub
		return this.relationshipRepository.findByParentEntityId(id);
	}

	@Override
	public List<Relationship> findByParentEntityIdAndKind(String id, String kind) {
		// TODO Auto-generated method stub
		return this.relationshipRepository.findByParentEntityIdAndKind(id, kind);
	}

	@Override
	public List<Relationship> findByChildEntityId(String id) {
		// TODO Auto-generated method stub
		return this.relationshipRepository.findByChildEntityId(id);
	}
}
