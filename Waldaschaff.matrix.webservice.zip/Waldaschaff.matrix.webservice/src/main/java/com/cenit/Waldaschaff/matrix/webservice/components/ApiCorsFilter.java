package com.cenit.Waldaschaff.matrix.webservice.components;

import com.cenit.Waldaschaff.matrix.webservice.entities.Auth;
import com.cenit.Waldaschaff.matrix.webservice.services.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpFilter;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import org.springframework.stereotype.Component;

@Component
public class ApiCorsFilter extends HttpFilter {

    @Autowired
    AuthService authService;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    protected void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "*"); // Content-Type, Authorization
        response.setHeader("Access-Control-Allow-Credentials", "true");

        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            response.setStatus(HttpServletResponse.SC_OK);
            return;
        }

        String token = request.getHeader("Authorization");
        if (!validateToken((HttpServletRequest) request, token)) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Invalid or missing token");
            return;
        }

        chain.doFilter(request, response);
    }

    private boolean validateToken(HttpServletRequest req, String token) {
        Auth auth = null;
        String url = req.getRequestURL().toString();
        if (url.contains("auth/login") || url.contains("entities/export") || url.contains("files")) return true;
        if (token != null) {
            // System.out.println("Token # " + token);
            auth = this.authService.findOneByToken(token);
        }
        return auth != null;
    }

    @Override
    public void destroy() {
    }
}
