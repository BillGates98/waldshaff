package com.cenit.Waldaschaff.matrix.webservice.serviceImpls;

import org.springframework.stereotype.Service;

import com.cenit.Waldaschaff.matrix.webservice.entities.User;
import com.cenit.Waldaschaff.matrix.webservice.repositories.UserRepository;
import com.cenit.Waldaschaff.matrix.webservice.services.UserService;

@Service
public class UserServiceImpl implements UserService {
	
	UserRepository userRepository;

	public UserServiceImpl(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}

	@Override
	public User findOneById(Long id) {
		// TODO Auto-generated method stub
		return this.userRepository.findOneById(id);
	}

}
